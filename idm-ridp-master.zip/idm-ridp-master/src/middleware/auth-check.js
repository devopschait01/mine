/**
 * This module is responsible for making sure that valid user id is 
 * present either in http header or a valid access token is present 
 * in Authorization header.
 * 
 * Note: using user id from http header "remote_user" is only for testing purposes.
 * It shoould never be enabled in any other environments other than developer laptops.
 *  
 * @author Kamal V
 */
/* eslint-disable max-len */
const _ = require('lodash');
const OktaJwtVerifier = require('@okta/jwt-verifier');
const httpContext = require('express-http-context');
const okta = require('../controllers/okta');
const config = require('../config/config').config;
const logger = require('../config/logger');
const dbUtils = require('../utils/db-utils');
const respHandler = require('../utils/response-handler');
const errorMessages = require('../config/config').errorsMessages;


const oktaJwtVerifier = new OktaJwtVerifier({
  issuer: process.env.OKTA_OAUTH_SERVER_URL || config.okta_oauth_server_url,
  clientId: process.env.OKTA_CLIENT_ID || config.okta_client_id
});

/**
 * Authorizes by checking for user id in Okta's access token. 
 * An additional flag is also provided to enable easy development.
 * "use_header" flag should never be set to true other than for
 * development purposes.
 * 
 * If token is validated sucessfuly, "req.user" is populated for
 * downstream consumption. 
 */
module.exports.authorize = async (req, res, next) => {
  const clientObj = getClientName(req);
  if (_.isEmpty(clientObj) || clientObj.clientName === '') {
    logger.error(`Authorization is denied because x-api-key is missing or is invalid. Key is ${req.headers['x-api-key']}`);
    respHandler.handleErrorResponse(res, 401, errorMessages.missingAPIKey);
  } else {
    req.client = clientObj.clientName;
    if (clientObj.authType === 'HTTP_HEADER') {
      if (req.headers.remote_user) {
        okta.getUser(req.headers.remote_user).then((r) => {
          if (r !== undefined) {
            req.user = req.headers.remote_user;
            httpContext.set('user', req.headers.remote_user);
            logger.debug(`Authorization is successful. User id is ${req.user} and client is ${clientObj.clientName}`);
            next();
          } else {
            respHandler.handleErrorResponse(res, 401, errorMessages.missingUserID);
          }
        }).catch((e) => {
          logger.info(`User check in okta failed for user ${req.headers.remote_user}`, e);
          respHandler.handleErrorResponse(res, 401, errorMessages.missingUserID);
        });
      } else {
        logger.info('Authorization is denied because user id is missing in the header');
        respHandler.handleErrorResponse(res, 401, errorMessages.missingUserID);
      }
    } else {
      checkOktaToken(req).then((result) => {
        if (result === 'FAILED') {
          logger.info('Authorization is denied because user access token validation failed.');
          respHandler.handleErrorResponse(res, 401, errorMessages.accessTokenValidationFailed);
        } else {
          req.user = result.claims.sub;
          httpContext.set('user', req.user);
          next();
        }
      }).catch((e) => {
        logger.info('Authorization is denied because user access token validation failed.', e);
        respHandler.handleErrorResponse(res, 401, errorMessages.accessTokenValidationFailed);
      });
    }
  }
};

function getClientName(req) {
  let clientObj;
  let apiKeys;
  // Check to make sure the x-api-key header is present and is valid.
  const clientKey = req.headers['x-api-key'];
  if (clientKey) {
    apiKeys = dbUtils.getAPIKeys();
    if (apiKeys) {
      apiKeys.forEach((key) => {
        if (clientKey.toLowerCase() === key.apiKey) { clientObj = key; }
      });
    }
  }
  return clientObj;
}

/**
 * Validates accessToken against Okta. Access token is expected to be present in Authorization Header. 
 * 
 * Expected header format: Authorization: Bearer 
 * 
 * @param {Request} req 
 * 
 * @returns if token is present and valid, returns jwt claims, else returns null. 
 */
async function checkOktaToken(req) {
  if (req.headers.authorization && req.headers.authorization.split(' ')[0] === 'Bearer') {
    const accessToken = req.headers.authorization.split(' ')[1];
    const result = await oktaJwtVerifier.verifyAccessToken(accessToken);
    return result;
  }
  logger.error('Authorization header is missing');
  return 'FAILED';
}