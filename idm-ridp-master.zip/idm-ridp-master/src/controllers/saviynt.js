/**
 * 
 * @author Mallik K
 */

/* eslint-disable guard-for-in */
/* eslint-disable no-undef */
const _ = require('lodash');
const axios = require('axios');
const logger = require('../config/logger');
const config = require('../config/config').config;
const redis = require('./redis-cache');

/**
 * update saviynt profile with ridp attributes.
 */
exports.updateProfileWithRIDPInfo = async (userId, data) => {
  let response;
  try {
    const user = { username: userId };
    if (!_.isEmpty(data.referenceNumber)) { user.customproperty30 = data.referenceNumber; }
    if (!_.isEmpty(data.score)) { user.customproperty31 = data.score; }
    if (!_.isEmpty(data.decision)) { user.customproperty32 = data.decision; }
    if (!_.isEmpty(data.errorCode)) { user.customproperty33 = data.errorCode; }
    response = updateUserProfileInSaviynt(user);
  } catch (e) {
    logger.error(`Error occurred while updating user profile with RIDP Info : ${userId}`, e);
    return {};
  }
  return response;
};

/**
 * update user profile in saviynt.
 */
exports.updateProfile = async (userId, data) => {
  let response;
  try {
    const user = { username: userId };
    buildUserData(user, data);
    response = await updateUserProfileInSaviynt(user);
  } catch (e) {
    logger.error(`Error occurred while updating user profile in saviynt : ${userId} data ${JSON.stringify(data)}`, e);
    return {};
  }
  return response;
};

async function updateUserProfileInSaviynt(userData) {
  let response = {};
  try {
    if (logger.isLevelEnabled('debug')) { logger.debug(`updateUserProfileInSaviynt : ${JSON.stringify(userData)}`); }
    response = await axios.post(
      `${process.env.SAVIYINT_LOGIN_URL || config.saviynt_url}/updateUser`,
      userData,
      getHeaderObject(await getToken())
    );

    if (response && response.data) {
      if (logger.isLevelEnabled('debug')) { logger.debug(`updateUserProfileInSaviynt completed ${JSON.stringify(response.data)}`); }
      return (response.data);
    }
    return response;
  } catch (e) {
    logger.warning(`Error while updating user profile information in saviynt for user ${JSON.stringify(userData)}`, e);
    throw e;
  }
}

async function getToken() {
  const token = await getNewToken();
  return token;
}

function getHeaderObject(accessToken) {
  return {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`
    }
  };
}

function getLoginUrl() {
  return process.env.SAVIYINT_LOGIN_URL || config.saviynt_login_url;
}

function getCredentials() {
  return {
    username: process.env.SAVIYNT_UID || config.saviynt_uid,
    password: process.env.SAVIYNT_PASSWORD || config.saviynt_password
  };
}

function buildUserData(user, data) {
  const loa = data.requestType;
  if (loa === 'LOA2') user.customproperty3 = 2;
  else if (loa === 'LOA3') { user.customproperty3 = 3; }
  user.firstname = data.firstName;
  user.lastname = data.lastName;
  user.customproperty2 = data.suffix;
  user.customproperty11 = data.address.zipcodeExtn;
  user.customproperty20 = data.address.line2;
  user.email = data.email;
  user.phonenumber = data.address.phone.replace(/-/g, '');
  user.customproperty19 = data.address.line1;
  user.city = data.address.city;
  user.state = data.address.state;
  user.customproperty10 = data.address.zipCode;
  user.customproperty32 = 'ACC'; // decisionCodeRidp
  if (!_.isEmpty(data.ssn)) {
    user.customproperty35 = cryptoJS.SHA256(data.ssn.replace('-', '')).toString();
  }
  user.customproperty37 = formatDOB(data.dateOfBirth);
}

function formatDOB(dob) {
  const dobTokens = dob.split('-'); // Because of prior validation, we can be sure DOB is always going to be there.
  return `${dobTokens[1]}/${dobTokens[2]}/${dobTokens[0]}`;
}

async function getNewToken() {
  try {
    logger.debug('Checking if access token exists in redis cache');
    const accessToken = await redis.getValue('SAVIYNT:ACCESS_TOKEN');
    if (accessToken) {
      logger.debug('Found access token exists in redis cache');
      return accessToken;
    }
    logger.debug('Access token not in redis cache. calling saviynt API to get token.');
    const authResponse = await axios.post(getLoginUrl(),
      getCredentials());
    const tokenObj = authResponse.data;
    logger.debug(`getting access token from Saviynt API call ${tokenObj.access_token}`);
    await redis.setValue('SAVIYNT:ACCESS_TOKEN', tokenObj.access_token, tokenObj.expires_in * 0.8); //
    return tokenObj.access_token;
  } catch (e) {
    logger.critical('RIDP_SAVIYNT_ERR: error getting token from redis or Saviynt API call', e);
    throw e;
  }
}