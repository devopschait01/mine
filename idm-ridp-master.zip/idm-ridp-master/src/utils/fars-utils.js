/**
 * This module contains some utility methods to handle FARS processing.
 * 
 * @author Srikanth M
 */
/* eslint-disable max-len */
const _ = require('lodash');
const xml2js = require('xml2js').parseString;
const config = require('../config/config').config;
const logger = require('../config/logger');


function getXMLVersion(farsObj) {
  const baseObj = farsObj['fraud-archive-reports']['archive-report'];
  if (baseObj.PreciseIDServer.PIDXMLVersion) {
    return baseObj.PreciseIDServer.PIDXMLVersion;
  }
  return baseObj.PreciseIDServer.XMLVersion;
}

function getPIDServerNode(farsObj) {
  return farsObj['fraud-archive-reports']['archive-report'].PreciseIDServer;
}

/**
 * This method will extract user information from FARS response object.
 * Note: This method is for version 4 of the response
 *
 * @param {*} farsObj
 */
function getDetailsFromVersionFour(farsObj) {
  const farsResponse = {};
  const userInfo = {};
  const pidNode = getPIDServerNode(farsObj);
  farsResponse.finalDecision = pidNode.Summary.FinalDecision;

  if (farsResponse.finalDecision === 'ACC') {
    farsResponse.responseStatus = 'SUCCESS';
  }
  const oowScore = pidNode.Summary.PreciseIDScore;

  if (oowScore === '9001' || oowScore === '9012' || oowScore === '9013') {
    farsResponse.status = 'FAIL';
  } else {
    farsResponse.status = 'SUCCESS';
  }

  const addressNode = pidNode.Checkpoint.StandardizedAddressDetail;
  const dobSummaryNode = pidNode.Checkpoint.GeneralResults;
  const ssnNode = pidNode.Checkpoint.ValidationSegment;
  userInfo.firstName = addressNode.FirstName;
  userInfo.lastName = addressNode.Surname;
  userInfo.dobMonth = dobSummaryNode.MonthOfBirth;
  userInfo.dobDay = dobSummaryNode.DayOfBirth;
  userInfo.dobYear = dobSummaryNode.YearOfBirth;
  userInfo.ssn = ssnNode.SSN;
  farsResponse.userInfo = userInfo;
  farsResponse.oowScore = oowScore;
  return farsResponse;
}

/**
 * This method will extract user information from FARS response object.
 * Note: This method is for version 6 of the response
 *
 * @param {*} farsObj
 */
function getDetailsFromVersionSix(farsObj) {
  const farsResponse = {};
  const userInfo = {};
  const pidNode = getPIDServerNode(farsObj);
  farsResponse.finalDecision = pidNode.Summary.FinalDecision;

  if (farsResponse.finalDecision === 'ACC') {
    farsResponse.responseStatus = 'SUCCESS';
  }
  const oowScore = pidNode.Summary.Scores.PreciseIDScore;

  if (oowScore === '9001' || oowScore === '9012' || oowScore === '9013') {
    farsResponse.status = 'FAIL';
  } else {
    farsResponse.status = 'SUCCESS';
  }

  const addressNode = pidNode.PreciseMatch.Addresses.Address.Detail.StandardizedAddressRcd;
  const dobSummaryNode = pidNode.PreciseMatch.DateOfBirth.Summary;
  userInfo.firstName = addressNode.FirstName;
  userInfo.lastName = addressNode.Surname;
  userInfo.dobMonth = dobSummaryNode.MonthOfBirth;
  userInfo.dobDay = dobSummaryNode.DayOfBirth;
  userInfo.dobYear = dobSummaryNode.YearOfBirth;
  userInfo.ssn = ''; // Where will SSN come from.
  farsResponse.userInfo = userInfo;
  farsResponse.oowScore = oowScore;
  return farsResponse;
}

function computeFinalStatus(statusCode, farsResponse) {
  let finalStatus = 200;
  if (statusCode === 200) {
    if (farsResponse.status === 'FAIL'
      || farsResponse.finalDecision === 'RF1'
      || farsResponse.finalDecision === 'RF4') { finalStatus = '202'; } else if (farsResponse.responseStatus === 'FAIL') { finalStatus = '201'; }
  } else if (statusCode === 204
    || farsResponse.finalDecision === 'RF2') {
    finalStatus = 204;
  } else {
    finalStatus = 203;
  }
  return finalStatus;
}

function isEqual(str1, str2) {
  return str1.toUpperCase() === str2.toUpperCase();
}

exports.getFARSConnectionDetails = (reviewRefNum) => {
  let subCode;

  if (reviewRefNum.startsWith('L3')) {
    subCode = process.env.LOA3_SUBCODE || config.loa3_subcode;
  } else {
    subCode = process.env.LOA2_SUBCODE || config.loa2_subcode;
  }
  logger.debug(`FARS Url:${process.env.FARS_URL || config.fars_url}&sub-cd=${subCode}&sub-ref=${reviewRefNum}`);
  const options = {
    url: `${process.env.FARS_URL || config.fars_url}&sub-cd=${subCode}&sub-ref=${reviewRefNum}`,
    headers: {
      Authorization: `Basic ${process.env.AUTH_KEY || config.auth_key}`,
      Accept: 'application/xml',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    }
  };

  return options;
};

exports.getFARSDetailsFromResponse = (statusCode, responseBody) => {
  let farsResponse = {};
  // TODO: This parsing should happen with async: true
  xml2js(responseBody, {
    trim: true, normalize: true, explicitArray: false, ignoreAttrs: true
  }, (err, result) => {
    if (!err) {
      const farsObj = result;
      if (logger.isLevelEnabled('private')) { logger.private(`Experian FARS Response: ${JSON.stringify(result)}`); }
      const farsXMLVersion = getXMLVersion(farsObj);
      if (farsXMLVersion === '4') {
        farsResponse = getDetailsFromVersionFour(farsObj);
      } else {
        farsResponse = getDetailsFromVersionSix(farsObj);
      }
      farsResponse.finalStatus = computeFinalStatus(statusCode, farsResponse);
      if (logger.isLevelEnabled('debug')) { logger.debug(`Final result in phone proofing: ${JSON.stringify(farsResponse)}`); }
    } else {
      logger.critical('RIDP_EXPERIAN_FARS_ERR: Error while parsing FARS XML to JSON ', err);
    }
  });
  return farsResponse;
};

exports.isAllDataPresentInFARSResponse = (farsUserInfo, requestType) => {
  if (!farsUserInfo
    || !farsUserInfo.dobYear
    || !farsUserInfo.dobMonth
    || !farsUserInfo.dobDay
    || !farsUserInfo.firstName
    || !farsUserInfo.lastName
    || (requestType === 'LOA3' && !farsUserInfo.ssn)) {
    logger.debug('isAllDataPresentInFARSResponse : returned false');
    return false;
  }

  logger.debug('isAllDataPresentInFARSResponse : returned true');
  return true;
};

exports.isUserInputDataMatchWithFARS = (userInput, farsUserInfo) => {
  if (logger.isLevelEnabled('private')) { logger.debug(`doesUserInputDataMatchWithFARS : User Input Data : ${JSON.stringify(userInput)}`); }
  const dob = `${farsUserInfo.dobYear}-${farsUserInfo.dobMonth}-${farsUserInfo.dobDay}`;
  if (!isEqual(farsUserInfo.firstName, userInput.firstName)
    || !isEqual(farsUserInfo.lastName, userInput.lastName)
    || (!_.isEmpty(farsUserInfo.ssn) && !isEqual(farsUserInfo.ssn, userInput.ssn))
    || !isEqual(dob, userInput.dateOfBirth)) {
    if (logger.isLevelEnabled('private')) { logger.debug(`doesUserInputDataMatchWithFARS : FARS User Data : ${JSON.stringify(farsUserInfo)}`); }
    return false;
  }
  logger.debug(`doesUserInputDataMatchWithFARS : returned true for user ${userInput.lastName} ${userInput.firstName}`);
  return true;
};