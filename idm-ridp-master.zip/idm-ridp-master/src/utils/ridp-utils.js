/**
 * Utility class to create a request JSON object to be sent to Experian for RIDP OOW questions.
 * 
 * @author Kamal V
 */
/* eslint-disable quotes */
const randomstring = require('randomstring');
const moment = require('moment');
const cryptoJS = require('crypto-js');
const config = require('../config/config').config;
const jwtUtils = require('./jwt-utils');

exports.generateJWTToken = (inputData) => {
  return jwtUtils.sign({ inputData }, config.jwt_token_expiresIn);
};

exports.verifyAndDecodeJWTToken = (inputData) => {
  return jwtUtils.sign(inputData, config.jwt_token_expiresIn);
};

/**
 * Calculates HMAC256 signature to be as header (hmac-signature) 
 * using the key provided by Experian.
 */
exports.calculateHMACSignature = (jsonStr) => {
  return cryptoJS.HmacSHA256(jsonStr, process.env.HMAC_SECRET || config.hmac_secret).toString(cryptoJS.enc.Base64);
};

//--------------------------------------------

exports.createKBAAnswersRequest = (body, inputData) => {
  return {
    header: createAnswersHeaderObj(inputData),
    payload: createAnswersPayloadObj(body, inputData)
  };
};

function createAnswersHeaderObj(inputData) {
  return {
    tenantId: process.env.TENANT_ID || config.tenant_id,
    requestType: config.request_type,
    clientReferenceId: inputData.referenceNumber,
    expRequestID: inputData.expRequestID,
    messageTime: getMessageTime(),
    options: {
      workflow: '',
      strategyManager: '',
      modelType: '',
      responseType: 1
    }
  };
}

function createAnswersPayloadObj(body, inputData) {
  return {
    control: createControlArrayObj(inputData.requestData.requestType),
    kba: createKBANode(body, inputData)
  };
}

function createKBANode(body, inputData) {
  return {
    sessionId: inputData.sessionId,
    answers: getAnswersObj(body)
  };
}

function getAnswersObj(body) {
  const answers = body.answers;
  const obj = {};
  answers.forEach((answer) => {
    const x = `outWalletAnswer${answer.question}`;
    obj[x] = answer.answer;
  });
  return obj;
}
//--------------------------------------------

exports.createOOWQuestionsRequest = (input) => {
  return {
    header: createHeaderObj(input),
    payload: createPayloadObj(input)
  };
};

function createHeaderObj(input) {
  return {
    tenantId: process.env.TENANT_ID || config.tenant_id,
    requestType: config.request_type,
    clientReferenceId: generateClientRefId(input),
    messageTime: getMessageTime(),
    options: {
      skipHMAC: 'true'
    }
  };
}

function createPayloadObj(input) {
  return {
    control: createControlArrayObj(input.requestType),
    contacts: createContactsObj(input),
    application: createApplicationObj(input)
  };
}

function createControlArrayObj(requestType) {
  return [
    { option: 'PIDXML_VERSION', value: config.pid_xml_version },
    { option: 'SUBSCRIBER_PREAMBLE', value: config.subscriber_preamble },
    { option: 'SUBSCRIBER_OPERATOR_INITIAL', value: config.subscriber_operator_initial },
    { option: 'SUBSCRIBER_SUB_CODE', value: getSubCode(requestType) },
    { option: 'PID_USERNAME', value: process.env.PID_USERNAME || config.uid },
    { option: 'PID_PASSWORD', value: process.env.PID_PASSWORD || config.password },
    { option: 'VERBOSE', value: config.verbose },
    { option: 'PRODUCT_OPTION', value: config.pid_version },
    { option: 'DETAIL_REQUEST', value: config.detail }
  ];
}

function createContactsObj(input) {
  const contact = [{
    id: 'APPLICANT_1',
    person: createPersonObj(input),
    addresses: createAddressObj(input),
    telephones: createTelephonesObj(input),
    emails: createEmailsObj(input),
    identityDocuments: createIdentityDocumentsObj(input)
  }];

  if (input.requestType === 'LOA2' && (!input.ssn || input.ssn.trim() === '')) {
    delete contact[0].identityDocuments;
  }

  return contact;
}

function createPersonObj(input) {
  return {
    typeOfPerson: 'APPLICANT',
    personIdentifier: 'PERSON_1',
    personDetails: {
      dateOfBirth: input.dateOfBirth,
      yearOfBirth: getYear(input.dateOfBirth),
      age: getAge(input.dateOfBirth)
    },
    names: createNamesObj(input)
  };
}

function createNamesObj(input) {
  return [{
    id: 'PERSON_NAME_1',
    firstName: input.firstName,
    middelNames: input.middelName,
    surName: sanitizeLastName(input.lastName),
    nameSuffix: input.suffix
  }];
}

function createAddressObj(input) {
  return [{
    id: 'CONTACT_ADDRESS_1',
    addressType: 'CURRENT',
    poBoxNumber: '',
    street: input.address.line1,
    street2: input.address.line2,
    postTown: input.address.city,
    postal: input.address.zipCode,
    stateProvinceCode: input.address.state
  }];
}

function createTelephonesObj(input) {
  return [{
    id: 'PHONE_1',
    number: input.address.phone
  }];
}

function createEmailsObj(input) {
  return [{
    id: 'EMAIL_1',
    email: input.email
  }];
}

function createIdentityDocumentsObj(input) {
  return [{
    documentNumber: input.ssn,
    documentType: 'SSN'
  }];
}

function createApplicationObj() {
  return {
    applicants: createApplicantsObj()
  };
}

function createApplicantsObj() {
  return [{
    contactId: 'APPLICANT_1',
    applicantType: 'APPLICANT'
  }];
}

function getAge(dob) {
  return moment().diff(dob, 'years');
}

function getYear(dob) {
  return moment(dob).year();
}

function getSubCode(requestType) {
  if (requestType === 'LOA2') return config.loa2_subcode;
  return config.loa3_subcode;
}


function generateClientRefId(input) {
  const str = randomstring.generate({ length: 8, charset: 'numeric' });
  if (input.requestType === 'LOA2') {
    return `L2${str}`;
  }
  return `L3${str}`;
}

function getMessageTime() {
  return `${new Date().toISOString().split('.').shift()}z`;
}

function sanitizeLastName(lastName) {
  return lastName.replace("''", "")
    .replace("D'", "D''")
    .replace("d'", "d''")
    .replace("L'", "L''")
    .replace("l'", "l''")
    .replace("O'", "O''")
    .replace("o'", "o''");
}