/**
 * 
 * A very rudimentary PII redacting utility. This is a very basic version at this point.
 * 
 * @author Kamal V
 */
/* eslint-disable linebreak-style */
const _ = require('lodash');

// look for json attirbute ssn or dob or dataOfBirth and erdact the data
exports.redact = (data, stringify) => {
  // Very rudimentary implementation just to handle SSN and DOB
  if (!_.isEmpty(data.ssn)) {
    const ssn = data.ssn;
    if (ssn.includes('-')) { data.ssn = `XXX-XX-${ssn.slice(-4)}`; }
    data.ssn = `XXXXX${ssn.slice(-4)}`;
  }
  if (!_.isEmpty(data.dateOfBirth)) {
    const dob = data.dateOfBirth;
    if (!_.isEmpty(dob) && dob.length > 4) {
      data.dateOfBirth = `${dob.substring(0, 4)}-XX-XX`;
    }
  }
  if (stringify) return JSON.stringify(data);
  return data;
};

exports.redactSSN = (ssn) => {
  let redactedSSN = '';
  if (!_.isEmpty(ssn) && ssn.length > 4) {
    if (ssn.includes('-')) { redactedSSN = `XXX-XX-${ssn.slice(-4)}`; }
    redactedSSN = `XXXXX${ssn.slice(-4)}`;
  }
  return redactedSSN;
};

exports.redactDOB = (dob) => {
  let redactedDOB = '';
  if (!_.isEmpty(dob) && dob.length > 4) {
    redactedDOB = `${dob.substring(0, 4)}-XX-XX`;
  }
  return redactedDOB;
};