
/**
 * Utility module that performs uniqueness checks needed as part of RIDP processing.
 * 
 * @author Kamal V
 */
/* eslint-disable indent */
/* eslint-disable max-len */
const _ = require('lodash');
const okta = require('../controllers/okta');
const logger = require('../config/logger');
const respHandler = require('../utils/response-handler');
const config = require('../config/config').config;
const errorMessages = require('../config/config').errorsMessages;


/**
 * This method performs the following two uniqueness checks in the order listed.
 * 1) last name, first name and email address.
 * 2) SSN
 *  
 */
exports.isDataUnique = async (req, res, next) => {
  logger.debug(`Starting combo uniqueness check request for user ${req.user}`);
  let isSSNUnique = false;
  let isComboUnique = false;

  await okta.isComboUniqueInOkta(req.user, req.body.lastName,
    req.body.firstName, req.body.email).then((result) => {
      if (result) isComboUnique = true;
      else {
        logger.debug(`Combo uniqueness check failed for user ${req.user}`);
        respHandler.handleErrorResponse(res, 400, errorMessages.comboUniquessCheck);
      }
    }).catch((err) => {
      logger.error(`Error occurrend while performing combo uniqueness check for user ${req.user}`, err);
      respHandler.handleErrorResponse(res, 400, errorMessages.comboUniquessCheck);
    });

  logger.debug(`Combo uniqueness check status is ${isComboUnique}. SSN present is ${!_.isEmpty(req.body.ssn)}`);

  if (_.isEmpty(req.body.ssn)) {
    isSSNUnique = true;
  }
  if (isComboUnique && !_.isEmpty(req.body.ssn)) {
    await okta.isSSNUniqueInOkta(req.user, req.body.ssn).then((result) => {
      if (result) isSSNUnique = true;
      else respHandler.handleErrorResponse(res, 400, errorMessages.ssnUniquessCheck);
    }).catch((err) => {
      logger.error(`Error occurrend while performing ssn uniqueness check for user ${req.user}`, err);
      respHandler.handleErrorResponse(res, 400, errorMessages.ssnUniquessCheck);
    });
  }

  logger.debug(`Information provided for user ${req.user} is unique : ${isSSNUnique && isComboUnique}`);

  if (isSSNUnique && isComboUnique) {
    next();
  }
};

/**
 * Purpose of this function is to check and see if user is already 
 * ID proofed as the desired proofing level. This check is performed
 * by looking at the LOA attribute in Okta.
 * 
 */
exports.isRIDPRequired = async (req, res, next) => {
  if (config.check_if_ridp_required) {
    logger.debug(`Starting is ridp required call for user ${req.user} and loa level ${req.body.requestType}`);
    await okta.getUser(req.user).then((user) => {
      const currentLOA = user.profile.LOA || '1';
      if ((req.body.requestType === 'LOA2' && (currentLOA === '2' || currentLOA === '3'))
        || ((req.body.requestType === 'LOA3' && currentLOA === '3'))) {
        logger.error(`This should never happen. User ${req.user} is already at the necessary LOA level.`);
        respHandler.handleErrorResponse(res, 400, errorMessages.ridpNotRequired);
      } else {
        logger.debug(`${req.user}'s current LOA level is ${currentLOA} and requested proofing level is ${req.body.requestType}. So ID proofing is required`);
        next();
      }
    }).catch((e) => {
      logger.error(`Error occurrend while checking to see if proofing is needed for user ${req.user}`, e);
      next();
    });
  } else {
    logger.debug(`Skipping is ridp required call for user ${req.user} and loa level ${req.body.requestType}`);
    next();
  }
};

/**
 * 
 */
exports.isFARSNeeded = async (req, res, next) => {
  logger.debug(`Starting is FARS needed call for user ${req.user} and loa level ${req.body.requestType}`);
  await okta.getUser(req.user).then((user) => {
    const currentLOA = user.profile.LOA || '1';
    if ((req.body.requestType === 'LOA2' && (currentLOA === '2' || currentLOA === '3'))
      || ((req.body.requestType === 'LOA3' && currentLOA === '3'))) {
      logger.error(`This should never happen. User ${req.user} is already at the necessary LOA level.`);
      respHandler.handleErrorResponse(res, 400, errorMessages.ridpNotRequired);
    } else if (!_.isEmpty(user.profile.refNumberRidp)
      && (_.isEmpty(user.profile.decisionCodeRidp)
        || user.profile.decisionCodeRidp !== 'ACC')) {
      logger.debug(`User ${req.user} is in phone proofing status`);
      next();
    }
  }).catch((e) => {
    logger.error(`Error occurrend while checking to see if user ${req.user} is in FARS status`, e);
    next();
  });
};