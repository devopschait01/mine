// const assert = require('assert');

// describe('IDM RIDP FARS Controller Unit Tests', function () {
//     it('should return number of charachters in a string', function () {
//         assert.equal("Hello".length, 5);
//     });
// });