/**
 *
 * @author Kamal V
 */
const fs = require('fs');
const jwt = require('jsonwebtoken');

// These keys should be secured better.
const privateKEY = fs.readFileSync('private.key', 'utf8');
const publicKEY = fs.readFileSync('public.key', 'utf8');

const Options = {
  issuer: 'CMS IDM',
  subject: 'CMS IDM',
  audience: 'Client_Identity'
};

module.exports = {
  sign: (payload, expiresIn) => {
    const signOptions = {
      issuer: Options.issuer,
      subject: Options.subject,
      audience: Options.audience,
      expiresIn,
      algorithm: 'RS256'
    };
    return jwt.sign(payload, privateKEY, signOptions);
  },
  verify: (token, expiresIn) => {
    const verifyOptions = {
      issuer: Options.issuer,
      subject: Options.subject,
      audience: Options.audience,
      expiresIn,
      algorithm: ['RS256']
    };
    try {
      return jwt.verify(token, publicKEY, verifyOptions);
    } catch (err) {
      return false;
    }
  },
  decode: (token) => { return jwt.decode(token, { complete: true }); }
};