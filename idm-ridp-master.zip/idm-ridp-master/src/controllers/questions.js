/**
 * The purpose of this module is to handle getting OOW questions from experian.
 * 
 * @author Kamal V
 */

/* eslint-disable max-len */
const _ = require('lodash');
const request = require('request');
const logger = require('../config/logger');
const config = require('../config/config').config;
const errorMessages = require('../config/config').errorsMessages;
const ridpUtils = require('../utils/ridp-utils');
const ridpErrorHandler = require('../utils/error-handler');
const respHandler = require('../utils/response-handler');
const okta = require('../controllers/okta');
const saviynt = require('../controllers/saviynt');

function getInfoForOutput(result) {
  return {
    referenceNumber: result.referenceNumber,
    questions: result.questions
  };
}

/**
 * Experian response is nested pretty deep. This helper function will return the
 * node that is contains PID Option 24 related response data.
 * @param {*} otherDataNode
 */
function getPIDServerNode(otherDataNode) {
  return otherDataNode.json.fraudSolutions.response.products.preciseIDServer;
}


/**
 * Check to see if we have an error in responseHeader.responseType node. 
 * These errors usually if the headers are not correct or if the HMAC 
 * signature did not match. General observation is these errors are 
 * coming from data conversion layer of Experian. Request did not even made
 * its way to Precise ID.
 *
 * @param {*} jsonResponse
 */
function isSystemError(jsonResponse, userId) {
  let result = false;
  if (!jsonResponse) { // This should never happen. Generate an alert
    logger.critical(`RIDP_EXPERIAN_ERR: Unrecoverable error occurred while fetching OOW questions for user ${userId}. JSON response is empty.`);
    result = true;
  } else if (_.isEmpty(jsonResponse)
    || _.isEmpty(jsonResponse.responseHeader)
    || jsonResponse.responseHeader.responseType === 'ERROR') {
    logger.critical(`RIDP_EXPERIAN_ERR: Unrecoverable error occurred while processing request for user : ${userId}. Response message is : ${jsonResponse.responseHeader.responseMessage}`);
    result = true;
  }
  return result;
}

/**
 * Extracts questions from experian response. If there are no questions, empty object
 * is returned.
 *
 * @param {*} otherDataNode
 */
function getQuestions(otherDataNode) {
  const questions = [];
  if (otherDataNode && otherDataNode.kba) {
    otherDataNode.kba.creditQuestionSet.forEach((item) => {
      const question = {
        question: item.relativeOrder,
        questionText: item.questionText,
        questionChoice: item.questionSelect.questionChoice
      };
      questions.push(question);
    });
    // nonCreditQuestionSet
    if (otherDataNode.kba.nonCreditQuestionSet) {
      otherDataNode.kba.nonCreditQuestionSet.forEach((item) => {
        const question = {
          question: item.relativeOrder,
          questionText: item.questionText,
          questionChoice: item.questionSelect.questionChoice
        };
        questions.push(question);
      });
    }
  }
  return questions;
}

/**
 * If the requests made it's way to precise Id, 
 * then otherData (clientResponsePayload.decisionElements[0].otherData)
 * node should always be there. Any errors precise Id 
 * sends are going to be part of the otherData node.
 *
 * @param {*} body
 * @returns 
 */
function processExperianResponse(body, userId) {
  const result = {
    errorCode: '',
    referenceNumber: '',
    expRequestId: '',
    sessionId: '',
    decision: '',
    score: ''
  };

  if (body.clientResponsePayload
    && body.clientResponsePayload.decisionElements
    && body.clientResponsePayload.decisionElements[0].otherData) {
    const pidNode = getPIDServerNode(body.clientResponsePayload.decisionElements[0].otherData);
    if (pidNode.error) {
      logger.debug(`Error occurred while processing OOW questions request for user ${userId}. Error code is ${pidNode.error.errorCode} and error description is ${pidNode.error.errorDescription}`);
      result.errorCode = pidNode.error.errorCode;
    }
    if (pidNode.sessionID) { result.sessionId = pidNode.sessionID; }
    if (pidNode.header) {
      if (pidNode.header.referenceNumber) { result.referenceNumber = pidNode.header.referenceNumber; }
      if (body.responseHeader.expRequestId) { result.expRequestId = body.responseHeader.expRequestId; }
    }
    if (pidNode.summary && pidNode.summary.finalDecision) {
      result.decision = pidNode.summary.finalDecision;
    }
    if (pidNode.summary && pidNode.summary.scores && pidNode.summary.scores.preciseIDScore) {
      result.score = pidNode.summary.scores.preciseIDScore;
    }
    result.questions = getQuestions(pidNode);
  } else {
    logger.error(`Error occurred while processing OOW questions request for user : ${userId}`);
    result.errorCode = -100; // Generic error.
  }

  if (result.errorCode === '' && result.decision !== 'XXX') {
    result.errorCode = result.decision;
  }
  return result;
}

/**
 * Method to send OOW questions request to Experian and if everything goes well,
 * extracts the OOW questions and sends them in the response.
 *
 * Note: Review reference number, PID and Decision Code/Error Code will have to
 * persisted to a data store. It is not implemented yet.
 *
 * Successful response contains the following:
 * {
    "questions": [
        {
            "order": 1,
            "questionText": "Question 1",
            "questionChoice": [
                "Answer choice 1",
                "Answer choice 2",
                "Answer choice 3",
                "Answer choice 4",
                "NONE OF THE ABOVE/DOES NOT APPLY"
            ]
        }
        upto 4 or 5 quesions.
    ],
    "inputDataToken": JWT token that contains the input data along with the session id.
}
*/
exports.viewRidpQuestions = (req, res) => {
  if (logger.isLevelEnabled('private')) {
    logger.debug(`Incoming OOW questions request for user ${req.user} is ${JSON.stringify(req.body)}`);
  }
  
  const tryCount = 2;
  /**
   * Both token and data validation will be completed by this time.
   * Uniqueness check validator will also be completed by now.
   * This is just dealing with experian communication
  */

  const inputData = req.body;
  // Just for testing purposes. We need some store to store this information.
  // if (inputData.tryCount) { tryCount = inputData.tryCount; }

  const json = ridpUtils.createOOWQuestionsRequest(inputData);
  if (logger.isLevelEnabled('private')) {
    logger.private(`Request to Experian for user ${req.user} is ${JSON.stringify(json)}`);
  }
  const hmacSignature = ridpUtils.calculateHMACSignature(JSON.stringify(json));

  const options = {
    url: process.env.CROSSCORE_URL || config.crosscore_url,
    headers: {
      'hmac-signature': hmacSignature,
      Accept: 'application/json',
      'Content-Type': 'application/json'
    },
    method: 'POST',
    json: true,
    body: json
  };

  /** Send the request to Experian now. */
  request.post(options, (err, response, body) => {
    try {
      if (logger.isLevelEnabled('private')) {
        logger.debug(`OOW Questions response form Experian for user ${req.user} is ${JSON.stringify(body)}`);
      }
      let jsonResponseObj = {};
      if (err || isSystemError(body, req.user)) {
        logger.error(`RIDP_EXPERIAN_ERR : Network error occurred while contacting Experian CrossCore for user ${req.user}`, err);
        respHandler.handleErrorResponse(res, 500, errorMessages.unexpectedError);
      } else {
        const result = processExperianResponse(body, req.user);
        if (result.decision === 'XXX' && result.questions && result.questions.length > 0) {
          // Got questions.
          jsonResponseObj = getInfoForOutput(result);
          jsonResponseObj.inputDataToken = ridpUtils.generateJWTToken({
            requestData: req.body,
            questionsCount: jsonResponseObj.questions.length,
            sessionId: result.sessionId,
            expRequestId: result.expRequestId,
            referenceNumber: result.referenceNumber
          });
          logger.debug(`Got OOW questions from Experian for user ${req.user}`);
          const x = `${jsonResponseObj.questions.length} question returned sucessfully. Reference number is ${result.referenceNumber}`;
          respHandler.handleSuccessResponse(res, jsonResponseObj, x);
        } else {
          logger.debug(`OOW questions are not returned by Experian for user ${req.user}`);
          respHandler.handleErrorResponse(res, 400,
            ridpErrorHandler.handleFirstRequestErrors(result.errorCode,
              tryCount, result.referenceNumber));
        }

        // Should we update okta after sending the response or should 
        // we do it before sending the response?? Let's do it after and 
        // if we have to, we can change it later.
        if (!_.isEmpty(result.referenceNumber)) {
          saviynt.updateProfileWithRIDPInfo(req.user, result).then((updateResponse) => {
            if (_.isEmpty(updateResponse) || updateResponse.errorCode !== '0') {
              logger.debug(`Update user ${req.user}'s information in Saviynt failed. now update in OKTA`);
              okta.updateOktaWithRIDPInfo(req.user, result).then(() => {
                logger.debug(`Updated user ${req.user}'s information in Okta successfully`);
              }).catch((e) => {
                logger.error(`Error occurred while updating ${req.user} informaiton in Okta. Experian reference number is Reference number is ${result.referenceNumber}`, e);
              });
            }
          });
        }
      }
    } catch (e) {
      logger.error(`Error occurred while processing the request for user : ${req.user}`, e);
      respHandler.handleErrorResponse(res, 500, errorMessages.generalError);
    }
  });
};