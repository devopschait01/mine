/* eslint-disable max-len */
/* eslint-disable no-undef */
const assert = require('assert');
const expect = require('chai').expect;
const errorHandler = require('../../src/utils/error-handler');

describe('IDM RIDP Error Handler Unit Tests', () => {
  it('returns preliminary error message for questions request for condition RF1', () => {
    const error = errorHandler.handleFirstRequestErrors('RF1', 1, 'L2000');
    assert.equal(error.errorMessage, 'We were unable to verify the information you provided. Check the information you have entered and try again.');
  });

  it('returns preliminary error with code E00132', () => {
    const error = errorHandler.handleFirstRequestErrors('RF1', 1, 'L2000');
    assert.equal(error.errorCode, 'E00132');
  });

  it('returns final error message contains review reference number L212345678', () => {
    const error = errorHandler.handleFirstRequestErrors('RF1', 2, 'L212345678');
    expect(error.errorMessage).to.match(/L212345678/);
  });

  it('returns final error with code E00132', () => {
    const error = errorHandler.handleFirstRequestErrors('RF1', 2, 'L2000');
    assert.equal(error.errorCode, 'E00120');
  });
});