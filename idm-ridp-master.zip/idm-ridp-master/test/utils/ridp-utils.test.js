/* eslint-disable no-unused-expressions */
/* eslint-disable no-undef */
const expect = require('chai').expect;
const assert = require('assert');
const ridpUtils = require('../../src/utils/ridp-utils');
// const logger = require('../../src/config/logger');
const config = require('../../src/config/config').config;
const jwtUtils = require('../../src/utils/jwt-utils');

const data = {
  requestType: 'LOA2',
  firstName: 'FIDENCIO',
  lastName: "BUZALD'A",
  middleName: 'B',
  suffix: '',
  email: 'radhak@c-hit.com',
  dateOfBirth: '1981-07-15',
  address: {
    type: 'US',
    line1: '4906 110TH AVENUE CT E APT B',
    line2: '',
    city: 'EDGEWOOD',
    state: 'WA',
    zipCode: '98372',
    zipcodeExtn: '',
    phone: '814-431-3990'
  },
  ssn: '666-14-1246'
};

describe('IDM RIDP Ridp Utils Unit Tests', () => {
  let oowQuestionsRequest;

  /**
   * Create the experian input object here and have test cases to check for the json.
   */

  before(() => {
    oowQuestionsRequest = ridpUtils.createOOWQuestionsRequest(data);
  });

  describe('IDM RIDP OOW Request Generation Tests', () => {
    it('should have header node', () => {
      expect(oowQuestionsRequest.header).to.not.be.empty;
    });

    it('should have payload node', () => {
      expect(oowQuestionsRequest.payload).to.not.be.empty;
    });

    it('should have requestType as PreciseIdOnly', () => {
      assert.equal((oowQuestionsRequest.header).requestType, 'PreciseIdOnly');
    });

    it('should replace one quote in last name with two quotes', () => {
      assert.equal(oowQuestionsRequest.payload.contacts[0].person.names[0].surName, "BUZALD''A");
    });
  });

  describe('JWT Token Related Unit Tests', () => {
    let jwtToken;
    before(() => {
      jwtToken = ridpUtils.generateJWTToken(data);
    });

    it('should make sure JWT token is generated', () => {
      expect(jwtToken).to.not.be.empty;
    });

    it('should make sure JWT token is valid and can be decoded', () => {
      const jwtResponseObj = jwtUtils.verify(jwtToken, config.jwt_token_expiresIn);
      const inputData = jwtResponseObj.inputData;
      expect(inputData).to.not.be.empty;
      assert.equal(inputData.firstName, 'FIDENCIO');
    });
  });
});