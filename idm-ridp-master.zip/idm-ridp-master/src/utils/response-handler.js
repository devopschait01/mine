/**
 * 
 * @author Kamal V
 */

// const logger = require('../config/logger');

exports.handleSuccessResponse = (res, response, logResponse) => {
  if (logResponse) { res.locals.response = logResponse; } else res.locals.response = response;
  res.status(200).json(response);
};

exports.handleErrorResponse = (res, code, errorObj, err) => {
  let msg;
  if (Array.isArray(errorObj)) {
    msg = { errors: errorObj };
  } else {
    msg = { errors: [errorObj] };
  }
  if (err) { res.locals.response = { errors: err }; } else { res.locals.response = msg; }
  res.status(code).json(msg);
};