/**
 * This module inserts the request starting timestamp. 
 * This is useful to calculate the elapsed time more 
 * preciesely.
 * 
 * @author Kamal V
 */

module.exports.insertstartHRTime = (req, res, next) => {
  req.hrTime = process.hrtime();
  next();
};