# IDM RIDP Microservice Implementation

Experian RIDP service implementation. This service talks to Experian for Identity Proofing and updates Okta when Identity Proofing is successfully completed.

## Development Setup
* docker build -t idm-ridp-local .
* docker run --rm -it -v ${pwd}:/usr/src/app -p 3500:3500/tcp idm-ridp-local:latest
* To keep the data, mount the data directory to a local directory.
* docker run -p3306:3306 --name mysql -v c:/data/mysql/datadir:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=Pa55word -d mysql:latest

## Non-Development Setup
* docker build -f Dockerfile.nonlocal -t idm-ridp .
* docker run --rm -p 3500:3500/tcp idm-ridp:latest

## Docker Compose Commands
The following docker compose commands can be used to start the microservice along with new database instance. As soon as code changes are saved in VSCODE, nodejs in node container will be automatically restarted.

* docker-compose build - this will build the containers (only need to be done once).
* docker-compose up - will start both nodejs and mysql container (mysq database will be reinitialized).
* docker-compose down - stops both mysql as well as nodejs containers.

### Configuration
Before running the instance in an integrated environment such as AWS, the following environment variables needs to be set.

Parameter | Description
------------ | -------------
PORT | Instance listen port
CROSSCORE_URL | Experian URL
OKTA_ORG_URL | URL of Okta organization
OKTA_TOKEN | Admin token to read and write information from Okta organization 
REDIS_PORT | Redis server port 
REDIS_HOST | Redis server host 
SAVIYNT_URL | Saviynt host URL
SAVIYINT_LOGIN_URL | Saviynt login URL
SAVIYNT_UID | Saviynt login ID 
SAVIYNT_PASSWORD | Password to login to Saviynt
OKTA_OAUTH_SERVER_URL | Okta authorization server URL
OKTA_CLIENT_ID | Okta client ID
DB_HOST | Database server host IP address 
DB_PORT | Database server port 
DB_USER | Database user ID
DB_PASSWORD | Database user password 
DB_NAME | Database name
LOA3_SUBCODE 
LOA2_SUBCODE
FARS_URL
AUTH_KEY
TENANT_ID
PID_USERNANE
PID_PASSWORD

## Running Unit Tests
The following command runs unit tests and also prints code coverage report.

* npm test

## Linting
Prior to checking in code to Git, always run the following command and fix any eslint recommendations.
* npm run lint

## Infrastrucutre Dependencies
For development purposes all infrastructure dependencies are captured in docker and docker compose configuration files. For all other environments, the following is needed.
* Node 10.15.3
* MySql 8.0..15
