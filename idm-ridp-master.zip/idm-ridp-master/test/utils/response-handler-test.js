/* eslint-disable linebreak-style */
/* eslint-disable no-unused-expressions */
/* eslint-disable no-undef */
const mockReq = require('sinon-express-mock').mockRes;
const mockRes = require('sinon-express-mock').mockRes;
const sinonChai = require('sinon-chai');
const assert = require('assert');
const expect = require('chai').expect;
const responseHandler = require('../../src/utils/response-handler');
const express = require('express');
const chai = require('chai');
const logger = require('../../src/config/logger');

chai.use(sinonChai);

describe('IDM RIDP: Response Handler Utils Unit Tests', () => {
  let successData;
  let failureErrorData;
  before(() => {
    successData = {
      foo: 'bar'
    };
    failureErrorData = {
      errorCode: 'E00113',
      errorMessage: 'The User data does not match'
    };
  });

  it('should have status code 200', () => {
    const res = mockRes();
    responseHandler.handleSuccessResponse(res, successData);
    expect(res.json).to.be.calledWith({ foo: successData.foo });
    expect(res.status).to.be.calledWith(200);
    assert.equal(res.locals.response.foo, 'bar');
  });

  it('should have response data in response locals', () => {
    const res = mockRes();
    responseHandler.handleSuccessResponse(res, successData);
    assert.equal(res.locals.response.foo, 'bar');
  });

  it('should have status code 400', () => {
    const res = mockRes();
    responseHandler.handleSuccessResponse(res, 400, failureErrorData);
    expect(res.status).to.be.calledWith(200);
  });

  it('should have status error code in response locals object', () => {
    const res = mockRes();
    responseHandler.handleErrorResponse(res, 400, failureErrorData);
    assert.equal(res.locals.response.errors[0].errorCode, 'E00113');
  });

  it('should have custom error message in response locals object', () => {
    const res = mockRes();
    responseHandler.handleErrorResponse(res, 400, failureErrorData, 'Test error message');
    assert.equal(res.locals.response.errors, 'Test error message');
  });
});