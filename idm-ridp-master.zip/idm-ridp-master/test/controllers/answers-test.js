// /* eslint-disable no-unused-expressions */
// /* eslint-disable no-unused-vars */
// /* eslint-disable import/newline-after-import */
// /* eslint-disable linebreak-style */
// /* eslint-disable no-undef */
// const sinon = require('sinon');
// const request = require('request');
// const chai = require('chai');
// const expect = require('chai').expect;
// const assert = require('chai').assert;
// const sinonChai = require('sinon-chai');
// const { spy, stub } = require('sinon');
// const mockReq = require('sinon-express-mock').mockReq;
// const ridpUtils = require('../../src/utils/ridp-utils');
// const answersController = require('../../src/controllers/answers');
// const logger = require('../../src/config/logger');
// const okta = require('../../src/controllers/okta');
// const saviynt = require('../../src/controllers/saviynt');
// const redis = require('../../src/controllers/redis-cache');

// chai.should();
// chai.use(sinonChai);
// // const inputJSON = require('../test-data/ridp-input-data.json');
// const rf1ResponseJSON = require('../test-data/oow-answers-rf2-response.json');
// const accResponseJSON = require('../test-data/oow-answers-ACC-response.json');

// chai.use(sinonChai);

// const base = 'http://localhost:3000';

// const body = {
//   // tryCount: '1',
//   requestType: 'LOA2',
//   firstName: 'FIDENCIO',
//   lastName: 'BUZALDUA',
//   middleName: 'B',
//   suffix: '',
//   email: 'radhak@c-hit.com',
//   dateOfBirth: '1981-07-15',
//   address: {
//     type: 'US',
//     line1: '4906 110TH AVENUE CT E APT B',
//     line2: '',
//     city: 'EDGEWOOD',
//     state: 'WA',
//     zipCode: '98372',
//     zipcodeExtn: '',
//     phone: '814-431-3990'
//   },
//   ssn: '666-14-1246'
// };

// const answersJson = {
//   answers: [
//     { question: 1, answer: 5 },
//     { question: 2, answer: 5 },
//     { question: 3, answer: 5 },
//     { question: 4, answer: 5 },
//     { question: 5, answer: 5 }
//   ],
//   inputDataToken: ''
// };

// const mockResponse = () => {
//   const res = {};
//   res.locals = {};
//   res.status = sinon.stub().returns(res);
//   res.json = sinon.stub().returns(res);
//   return res;
// };

// describe('IDM RIDP Answers Controller Unit Tests', () => {
//   describe('IDM RIDP Answers Controller ACC Condition Unit Tests', () => {
//     let responseObject;

//     let req;
//     let res;
//     beforeEach(() => {
//       responseObject = {
//         statusCode: 200,
//         headers: {
//           'content-type': 'application/json'
//         }
//       };
      
//       this.getValue = sinon.stub(redis, 'getValue');
//       this.calculateHMACSignature = sinon.stub(ridpUtils, 'calculateHMACSignature');
//       this.generateJWTToken = sinon.stub(ridpUtils, 'generateJWTToken');
//       this.updateProfile = sinon.stub(saviynt, 'updateProfile');
//       this.updateProfileWithRIDPInfo = sinon.stub(saviynt, 'updateProfileWithRIDPInfo');
//       this.updateOktaWithRIDPInfo = sinon.stub(okta, 'updateOktaWithRIDPInfo');
//       this.post = sinon.stub(request, 'post');

//       res = mockResponse();
//       req = mockReq();
//       res.locals.inputData = {
//         requestData: body,
//         questionsCount: 5,
//         sessionId: 'ADADADAEW3WEC',
//         expRequestId: 'L334567890',
//         referenceNumber: 'L334567890'
//       };
//       req.body = answersJson;
//       req.user = 'test@test.com';
//       this.calculateHMACSignature.returns({});
//       this.generateJWTToken.returns({});
//       this.post.yields(null, responseObject, accResponseJSON);
//       this.updateProfile.returns({ errorCode: '0' });
//       this.updateProfileWithRIDPInfo.returns({ errorCode: '0' });
//       this.updateOktaWithRIDPInfo.resolves('');
//       answersController.verifyRidpAnswers(req, res);
//     });

//     afterEach(() => {
//       ridpUtils.generateJWTToken.restore();
//       ridpUtils.calculateHMACSignature.restore();
//       saviynt.updateProfile.restore();
//       saviynt.updateProfileWithRIDPInfo.restore();
//       redis.getValue.restore();
//       request.post.restore();
//       okta.updateOktaWithRIDPInfo.restore();
//     });

//     describe('GET /api/v1/idm/ridp/answers', () => {
//       it('should return 200 status code', (done) => {
//         //res.status.calledWith(200).should.be.ok;
//         done();
//       });
//     });
//   });

//   describe('IDM RIDP Answers Controller RF2 Condition Unit Tests', () => {
//     let responseObject;

//     let req;
//     let res;
//     beforeEach(() => {
//       responseObject = {
//         statusCode: 200,
//         headers: {
//           'content-type': 'application/json'
//         }
//       };
//       this.getValue = sinon.stub(redis, 'getValue');
//       this.calculateHMACSignature = sinon.stub(ridpUtils, 'calculateHMACSignature');
//       this.generateJWTToken = sinon.stub(ridpUtils, 'generateJWTToken');
//       this.updateProfile = sinon.stub(saviynt, 'updateProfile');
//       this.updateProfileWithRIDPInfo = sinon.stub(saviynt, 'updateProfileWithRIDPInfo');
//       this.updateOktaWithRIDPInfo = sinon.stub(okta, 'updateOktaWithRIDPInfo');
//       this.post = sinon.stub(request, 'post');

//       res = mockResponse();
//       req = mockReq();
//       res.locals.inputData = {
//         requestData: body,
//         questionsCount: 5,
//         sessionId: 'ADADADAEW3WEC',
//         expRequestId: 'L334567890',
//         referenceNumber: 'L334567890'
//       };
//       req.body = answersJson;
//       req.user = 'test@test.com';
//       this.calculateHMACSignature.returns({});
//       this.generateJWTToken.returns({});
//       this.post.yields(null, responseObject, rf1ResponseJSON);
//       this.updateProfile.returns({ errorCode: '0' });
//       this.updateProfileWithRIDPInfo.returns({ errorCode: '0' });
//       this.updateOktaWithRIDPInfo.resolves('');
//       answersController.verifyRidpAnswers(req, res);
//     });

//     afterEach(() => {
//       ridpUtils.generateJWTToken.restore();
//       ridpUtils.calculateHMACSignature.restore();
//       saviynt.updateProfile.restore();
//       saviynt.updateProfileWithRIDPInfo.restore();
//       redis.getValue.restore();
//       request.post.restore();
//       okta.updateOktaWithRIDPInfo.restore();
//     });

//     describe('GET /api/v1/idm/ridp/answers', () => {
//       it('should return 400 status code', (done) => {
//         //res.status.calledWith(400).should.be.ok;
//         done();
//       });
//       it('should return error code E00135', (done) => {
//         //assert.equal(res.locals.response.errors[0].errorCode, 'E00135');
//         done();
//       });
//     });
//   });
// });