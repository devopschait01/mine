/* eslint-disable no-underscore-dangle */
/* eslint-disable func-call-spacing */
/* eslint-disable no-spaced-func */
/* eslint-disable no-unused-expressions */
/* eslint-disable no-undef */
const mockReq = require('sinon-express-mock').mockReq;
const mockRes = require('sinon-express-mock').mockRes;
const sinonChai = require('sinon-chai');
// const assert = require('assert');
const expect = require('chai').expect;
const assert = require('chai').assert;
const chai = require('chai');

// const { spy, stub } = require('sinon');
const rewire = require('rewire');
const BaseJoi = require('@hapi/joi');
const Extension = require('@hapi/joi-date');

const validator = require('../../src/utils/validator');
const ridpUtils = require('../../src/utils/ridp-utils');


const Joi = BaseJoi.extend(Extension);
const rewiredValidator = rewire('../../src/utils/validator');
//const logger = require('../../src/config/logger');


chai.should();
chai.use(sinonChai);
chai.use(require('chai-string'));

let body = {
  // tryCount: '1',
  requestType: 'LOA2',
  firstName: 'FIDENCIO',
  lastName: 'BUZALDUA',
  middleName: 'B',
  suffix: '',
  email: 'radhak@c-hit.com',
  dateOfBirth: '1981-07-15',
  address: {
    type: 'US',
    line1: '4906 110TH AVENUE CT E APT B',
    line2: '',
    city: 'EDGEWOOD',
    state: 'WA',
    zipCode: '98372',
    zipcodeExtn: '',
    phone: '814-431-3990'
  },
  ssn: '666-14-1246'
};

describe('IDM RIDP: OOW Questions Validation Unit Tests', () => {
  // let req;
  // let status;
  // let json;
  // let res;

  const schema = rewiredValidator.__get__('schema');

  // let locals = {};
  beforeEach(() => {
    body = {
      // tryCount: '1',
      requestType: 'LOA2',
      firstName: 'FIDENCIO',
      lastName: 'BUZALDUA',
      middleName: 'B',
      suffix: '',
      email: 'radhak@c-hit.com',
      dateOfBirth: '1981-07-15',
      address: {
        type: 'US',
        line1: '4906 110TH AVENUE CT E APT B',
        line2: '',
        city: 'EDGEWOOD',
        state: 'WA',
        zipCode: '98372',
        zipcodeExtn: '',
        phone: '814-431-3990'
      },
      ssn: '666-14-1246'
    };
    // status = stub();
    // json = spy();

    // res = { json, status, locals };
    // status.returns(res);
    // req.user = 'testuser';
    // req.body = body;
  });

  it('should be sucessful', async () => {
    const result = await Joi.validate(body, schema, { abortEarly: false });
    assert.equal(result.error, null);
  });

  it('should fail validation becuase input data is empty', async () => {
    let result;
    body = {};
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.startsWith('ValidationError: child "requestType"');
    expect(result).to.containIgnoreCase('child "firstName" fails');
    expect(result).to.containIgnoreCase('child "lastName" fails');
    expect(result).to.containIgnoreCase('child "email" fails');
    expect(result).to.containIgnoreCase('child "dateOfBirth" fails');
  });

  it('should fail validation becuase input data is empty', async () => {
    let result;
    body = {
      // tryCount: '1',
      requestType: 'LOA22',
      firstName: 'FIDENCIOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA~!@#',
      lastName: 'BUZALDUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA~!@#',
      middleName: 'B',
      suffix: '',
      email: 'radhak@c-hitcom',
      dateOfBirth: 'abcd',
      address: {
        type: 'US',
        line1: '4906 110TH AVENUE CT E APT B@!~`',
        line2: '',
        city: 'EDGEWOOD~!@`',
        state: 'WAA',
        zipCode: '9837234',
        zipcodeExtn: '',
        phone: '814-431-39902222'
      },
      ssn: '666-14-1246111'
    };
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.containIgnoreCase('child "requestType"');
    expect(result).to.containIgnoreCase('child "firstName" fails');
    expect(result).to.containIgnoreCase('child "lastName" fails');
    expect(result).to.containIgnoreCase('child "email" fails');
    expect(result).to.containIgnoreCase('child "dateOfBirth" fails');
  });

  it('should fail validaton because first name is blank', async () => {
    let result;
    body.firstName = '';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
      body.firstName = 'FIDENCIO';
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.startsWith('ValidationError: child "firstName"');
  });

  it('should fail validaton because first name is contains invalid character', async () => {
    let result;
    body.firstName = 'FIDENCI^O';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.startsWith('ValidationError: child "firstName"');
  });
  it('should fail validaton because first name is too long', async () => {
    let result;
    body.firstName = 'FIDENCIOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.startsWith('ValidationError: child "firstName"');
  });
  it('should fail validaton because first name is too short', async () => {
    let result;
    body.firstName = '';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.startsWith('ValidationError: child "firstName"');
  });
  it('should fail validaton because DOB is not in valid format', async () => {
    let result;
    body.dateOfBirth = '10/10/2000';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.containIgnoreCase('child "dateOfBirth" fails');
  });
  it('should fail validaton because DOB is under 18 years', async () => {
    let result;
    body.dateOfBirth = '2010-01-01';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.containIgnoreCase('child "dateOfBirth" fails');
  });
  it('should fail validaton because ssn is missing for LOA3', async () => {
    let result;
    body.ssn = '';
    body.requestType = 'LOA3';
    try {
      await Joi.validate(body, schema, { abortEarly: false });
    } catch (e) {
      result = e.toString();
    }
    expect(result).to.containIgnoreCase('child "ssn" fails');
  });

  describe('IDM RIDP: OOW Answers Validation Unit Tests', () => {
    const answersJson = {
      answers: [
        { question: 1, answer: 5 },
        { question: 2, answer: 5 },
        { question: 3, answer: 5 },
        { question: 4, answer: 5 },
        { question: 5, answer: 5 }
      ],
      inputDataToken: ''
    };
    before(() => {
      /**
       * In our test case there are 5 questions. 
       * SessionId is "ADADADAEW3WEC"
       * reference number is L334567890
       * expRequestId is also same as reference number
       */
      inputToken = ridpUtils.generateJWTToken({
        requestData: body,
        questionsCount: 5,
        sessionId: 'ADADADAEW3WEC',
        expRequestId: 'L334567890',
        referenceNumber: 'L334567890'
      });
    });

    it('should validate OOW answers sucessfully', () => {
      answersJson.inputDataToken = inputToken;
      const res = mockRes();
      const req = mockReq();
      req.user = 'test';
      req.body = answersJson;
      validator.vaidateAnswers(req, res, () => {
        assert.equal(true, true);
      });
    });

    it('should contain a valid json object in res.locals.inputData', () => {
      answersJson.inputDataToken = inputToken;
      const res = mockRes();
      const req = mockReq();
      req.user = 'test';
      req.body = answersJson;
      validator.vaidateAnswers(req, res, () => {
        assert.exists(res.locals.inputData);
      });
    });

    it('should fail validation becuase input token is invalid', () => {
      answersJson.inputDataToken = `${inputToken}1`;
      const res = mockRes();
      const req = mockReq();
      req.user = 'test';
      req.body = answersJson;
      validator.vaidateAnswers(req, res, () => {
        assert.equal(false, true);
      });
      expect(res.status).to.be.calledWith(400);
      assert.equal(res.locals.response.errors[0].errorCode, 'E00107');
      assert.notExists(res.locals.inputData);
    });

    it('should fail validation becuase input token is missing', () => {
      answersJson.inputDataToken = '';
      const res = mockRes();
      const req = mockReq();
      req.user = 'test';
      req.body = answersJson;
      validator.vaidateAnswers(req, res, () => {
        assert.equal(false, true);
      });
      expect(res.status).to.be.calledWith(400);
      assert.equal(res.locals.response.errors[0].errorCode, 'E00107');
      assert.notExists(res.locals.inputData);
    });

    it('should fail validation becuase of fewer answers than expected', () => {
      answersJson.inputDataToken = inputToken;
      const res = mockRes();
      const req = mockReq();
      req.user = 'test';
      const oneNode = answersJson.answers.pop();
      req.body = answersJson;
      validator.vaidateAnswers(req, res, () => {
        // Sould not come here.
        assert.equal(false, true);
      });
      assert.equal(res.locals.response.errors[0].errorCode, 'E00108');
      answersJson.answers.push(oneNode); // restore
    });

    it('should fail validation becuase answer has value that is not expected', () => {
      answersJson.inputDataToken = inputToken;
      const res = mockRes();
      const req = mockReq();
      req.user = 'test';
      answersJson.answers[0].answer = '';
      req.body = answersJson;
      validator.vaidateAnswers(req, res, () => {
        // Sould not come here.
        assert.equal(false, true);
      });
      assert.equal(res.locals.response.errors[0].errorCode, 'E00108');
      // restore
      answersJson.answers[0].answer = 5;
    });

    it('should fail validaton because email is blank', async () => {
      let result;
      const localEmail = body.email;
      body.email = '';
      try {
        await Joi.validate(body, schema, { abortEarly: false });
        body.email = localEmail;
      } catch (e) {
        result = e.toString();
      }
      expect(result).to.startsWith('ValidationError: child "email"');
    });

    it('should fail validaton because email is more than 74 characters', async () => {
      let result;
      const localEmail = body.email;
      body.email = 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttes@gmail.com';
      try {
        await Joi.validate(body, schema, { abortEarly: false });
      } catch (e) {
        result = e.toString();
      }
      body.email = localEmail;
      expect(result).to.startsWith('ValidationError: child "email"');
    });
      
    it('should pass email validaton', async () => {
      let result;
      const localEmail = body.email;
      body.email = 'testtesttesttesttesttesttesttesttesttesttestt@gmail.com';
      try {
        await Joi.validate(body, schema, { abortEarly: false });
      } catch (e) {
        result = e.toString();
      }
      body.email = localEmail;
      assert.equal(result, undefined);
    });
  });
});