/* eslint-disable no-unused-expressions */
/* eslint-disable max-len */
/* eslint-disable no-undef */
const expect = require('chai').expect;
const fs = require('fs');
const path = require('path');
const farsUtils = require('../../src/utils/fars-utils');
const config = require('../../src/config/config').config;

const validationDataJson = require('../test-data/fars-utils-validation-data.json');

describe('IDM RIDP Fars Utils Unit Tests', () => {
  describe('IDM RIDP Fars Success XML parsing and validation Unit Tests', () => {
    let successXML;
    let successJSON;
    before(() => {
      successXML = fs.readFileSync(path.join(__dirname, '../test-data/fars-success.xml'), 'utf8');
      successJSON = farsUtils.getFARSDetailsFromResponse(200, successXML);
    });

    it('should have loa3 subcode in url', () => {
      const fars = farsUtils.getFARSConnectionDetails('L3343535');
      expect(fars.url).to.have.string(process.env.LOA3_SUBCODE || config.loa3_subcode);
    });

    it('should have loa2 subcode in url', () => {
      const fars = farsUtils.getFARSConnectionDetails('L2343535');
      expect(fars.url).to.have.string(process.env.LOA2_SUBCODE || config.loa2_subcode);
    });

    /**
     * Success XML test cases
     */

    it('should have status code of 200 (ACC)', () => {
      expect(successJSON.finalStatus).to.be.equal(200);
    });

    it('should have OOW score of 656', () => {
      expect(successJSON.oowScore).to.be.equal('656');
    });

    it('should have OBERMUELLER as last name', () => {
      expect(successJSON.userInfo.lastName).to.be.equal('OBERMUELLER');
    });

    it('should have JULIE as first name', () => {
      expect(successJSON.userInfo.firstName).to.be.equal('JULIE');
    });

    it('should have valid ssn', () => {
      expect(successJSON.userInfo.ssn).to.be.equal('666-17-6172');
    });
  });

  describe('IDM RIDP Fars RF2 XML parsing and validation Unit Tests', () => {
    let rf2XML;
    let rf2JSON;
    // let rf3JSON;
    before(() => {
      rf2XML = fs.readFileSync(path.join(__dirname, '../test-data/fars-rf2.xml'), 'utf8');
      rf2JSON = farsUtils.getFARSDetailsFromResponse(200, rf2XML);
      rf3JSON = farsUtils.getFARSDetailsFromResponse(200, fs.readFileSync(path.join(__dirname, '../test-data/fars-rf2.xml'), 'utf8'));
      // rf3JSON.finalDecision = 'RF3';
    });

    /**
     * Success XML test cases
     */

    it('should have status code of 200 (ACC)', () => {
      // const response = farsUtils.getFARSDetailsFromResponse(200, successXML);
      expect(rf2JSON.finalStatus).to.be.equal(200);
    });

    it('should have final decision RF2', () => {
      expect(rf2JSON.finalDecision).to.be.equal('RF2');
    });

    it('should have final decision RF2', () => {
      expect(rf2JSON.finalDecision).to.be.equal('RF2');
    });

    // it('should have final status 203', () => {
    //   expect(rf3JSON.finalStatus).to.be.equal('203');
    // });
  });

  describe('IDM RIDP Fars Data Validation Unit Tests', () => {

    it('required data validation should return true for LOA2', () => {
      const result = farsUtils.isAllDataPresentInFARSResponse(validationDataJson.loa2GoodData, 'LOA2');
      expect(result).to.be.equal(true);
    });

    it('required data validation should return false for LOA2', () => {
      const result = farsUtils.isAllDataPresentInFARSResponse(validationDataJson.loa2BadData, 'LOA2');
      expect(result).to.be.equal(false);
    });

    it('required data validation should return true for LOA3', () => {
      const result = farsUtils.isAllDataPresentInFARSResponse(validationDataJson.loa3GoodData, 'LOA3');
      expect(result).to.be.equal(true);
    });

    it('required data validation should return false for LOA3', () => {
      const result = farsUtils.isAllDataPresentInFARSResponse(validationDataJson.loa3BadData, 'LOA3');
      expect(result).to.be.equal(false);
    });
  });

  describe('IDM RIDP Fars Data Validation With Experian Data Unit Tests', () => {

    let successXML;
    let successJSON;
    before(() => {
      successXML = fs.readFileSync(path.join(__dirname, '../test-data/fars-success.xml'), 'utf8');
      successJSON = farsUtils.getFARSDetailsFromResponse(200, successXML);
    });

    it('required data validation should return true', () => {
      const result = farsUtils.isUserInputDataMatchWithFARS(validationDataJson.dataMatchingWithExperian, successJSON.userInfo);
      expect(result).to.be.equal(true);
    });

    it('required data validation should return false', () => {
      const result = farsUtils.isUserInputDataMatchWithFARS(validationDataJson.dataNotMatchingWithExperian, successJSON.userInfo);
      expect(result).to.be.equal(false);
    });
  });
  describe('IDM RIDP Fars parsing failure unit tests', () => {


    it('required data validation should return true', () => {
      const result = farsUtils.getFARSDetailsFromResponse(200, 'test respose in non xml format');
      expect(result).to.be.empty;
    });
  });
});