/**
 * This module encapsulates all the database activities.
 * 
 * @author Kamal V
 */
/* eslint-disable max-len */
const assert = require('assert');
const mysql = require('mysql');
const logger = require('../config/logger');
const config = require('../config/config').config;
const redactUtils = require('./redact-utils');


const AUDIT_EVENTS = [];
const API_KEYS = [];

const useDatabase = config.use_database;
/**
 * TODO: Should be using connection pool here.
 */
function getDBConnectionPool() {
  try {
    const pool = mysql.createPool({
      connectionLimit: 10,
      host: process.env.DB_HOST || config.db_host,
      port: process.env.DB_PORT || config.db_port,
      user: process.env.DB_USER || config.db_user,
      password: process.env.DB_PASSWORD || config.db_password,
      database: process.env.DB_NAME || config.db_name
    });
    return pool;
  } catch (e) {
    logger.critical('RIDP_DB_ERR: Error while getting connection to database', e);
    throw e;
  }
}

const pool = getDBConnectionPool();

/**
 * Connect to database and get the Event types. This problem with
 * this is, if a new event type is added, we need to recycle to pick it up. 
 * TODO: Need to fix this.
 */


function getAuditEvents() {
  pool.getConnection((err, connection) => {
    if (err) {
      logger.critical('RIDP_DB_ERR: Error while getting connection from connection pool', err);
      throw err;
    }

    // Use the connection
    connection.query('SELECT * FROM AUDIT_EVENT_TYPE', (error, result) => {
      if (error) {
        logger.critical('RIDP_DB_ERR: Error while getting audit event types from database ', error);
        connection.release();
        throw error;
      }
      const keys = Object.keys(result);
      for (const key of keys) {
        AUDIT_EVENTS.push({
          eventId: result[key].ID,
          eventName: result[key].NAME
        });
      }
      // When done with the connection, release it.
      connection.release();
    });
  });
}

/**
 * Reads API client keys from the database and stores them in cache.
 * TODO: Handle flushing the cache to account for new key addition.
 */
function getClients() {
  pool.getConnection((err, connection) => {
    if (err) {
      logger.critical('RIDP_DB_ERR: Error while getting connection from connection pool', err);
      throw err;
    }

    // Use the connection
    connection.query('SELECT * FROM API_KEY', (error, result) => {
      if (error) {
        logger.critical('RIDP_DB_ERR: Error while getting client keys information from database', error);
        connection.release();
        throw error;
      }
      const keys = Object.keys(result);
      for (const key of keys) {
        API_KEYS.push({
          apiKey: result[key].API_KEY,
          clientName: result[key].CLIENT_NAME,
          authType: result[key].AUTH_TYPE
        });
      }
      // When done with the connection, release it.
      connection.release();
    });
  });
}

getAuditEvents();

getClients();

assert(API_KEYS);
assert(AUDIT_EVENTS);

exports.getAPIKeys = () => { return API_KEYS; };

function getEventType(reqPath) {
  let eventId = 100;
  let event;
  if (reqPath.includes('questions')) {
    event = 'QUESTIONS';
  } else if (reqPath.includes('answers')) {
    event = 'ANSWERS';
  } else if (reqPath.includes('phone')) {
    event = 'FARS';
  }
  for (const audEvent of AUDIT_EVENTS) {
    if (audEvent.eventName === event) eventId = audEvent.eventId;
  }
  return eventId;
}

function getElapsedTimeInMilliSeconds(hrTime) {
  if (hrTime) {
    const nanoseconds = (hrTime[0] * 1e9) + hrTime[1];
    return nanoseconds / 1e6;
  }
  return 0;
}

function createDataObject(req, res) {
  let finalStatus;
  let user = '';
  if (req.user !== undefined) user = req.user.toUpperCase();
  const eventType = getEventType(req.path);
  if (res.statusCode === 200) finalStatus = 'SUCCESS';
  else finalStatus = 'FAIL';
  const insertData = {
    EVENT_TYPE_ID: eventType,
    TX_ID: req.txId,
    CLIENT: req.client,
    RESULT: finalStatus,
    ACTOR: user,
    DETAILS1: JSON.stringify(sanitizeData(req.path, req.body)),
    DETAILS2: JSON.stringify(res.locals.response),
    ELAPSED_TIME: getElapsedTimeInMilliSeconds(process.hrtime(req.hrTime)),
    HTTP_STATUS: res.statusCode
  };
  return insertData;
}

exports.insertAuditEvent = async (req, res) => {
  const insertData = createDataObject(req, res);
  if (useDatabase) {
    pool.getConnection((err, connection) => {
      if (err) {
        logger.critical('RIDP_DB_ERR: Error while getting connection from connection pool', err);
        throw err;
      }

      // Use the connection
      connection.query('INSERT INTO AUDIT_EVENT SET ?', insertData, (e) => {
        if (e) {
          logger.critical(`RIDP_DB_ERR: Error occurred while inserting audit information in database. 
                        Adudit data is ${JSON.stringify(insertData)}`, e);
        }
        // When done with the connection, release it.
        connection.release();
      });
    });
  } else {
    logger.debug(`Audit event is : ${JSON.stringify(insertData)}`);
  }
};

function sanitizeData(reqPath, data) {
  if (reqPath.includes('questions') || reqPath.includes('phone')) {
    const ssn = data.ssn;
    const dob = data.dateOfBirth;
    data.ssn = redactUtils.redactSSN(ssn);
    data.dateOfBirth = redactUtils.redactDOB(dob);
    return data;
  }

  if (reqPath.includes('answers')) {
    return 'Answers redacted';
  }

  return data;
}