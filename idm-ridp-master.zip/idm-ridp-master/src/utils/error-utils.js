/**
 * 
 * @author Kamal V
 */
exports.formatErrors = (e) => {
  const dataErrors = [];
  for (let i = 0; i < e.details.length; i += 1) {
    const errorMessage = e.details[i].message;
    dataErrors.push(errorMessage);
  }
  return { errors: dataErrors };
};