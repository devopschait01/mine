module.exports = {
  "extends": "airbnb-base",
  "rules": {
    "linebreak-style" : 0, 
    "comma-dangle": ["error", "never"],
    "max-len": ["error", { "code": 150 }],
    "arrow-body-style": ["error", "always"],
    "eol-last": ["error", "never"],
    "no-param-reassign": ["error", { "props": false }],
    "no-restricted-syntax": ["error", "FunctionExpression", "WithStatement", "BinaryExpression[operator='in']"],
    "no-trailing-spaces": ["error", { "ignoreComments": true, "skipBlankLines": true }],
    "prefer-destructuring": ["error", {
      "array": false,
      "object": false
    }, {
        "enforceForRenamedProperties": false
      }],
    "trailing-comma": [false, { "multiline": "always", "singleline": "never" }],
    // disallow the use of variables before they are defined
    "no-use-before-define": [
      2,
      {
        "functions": false,
        "classes": true,
        "variables": true
      }
    ],
  }
};