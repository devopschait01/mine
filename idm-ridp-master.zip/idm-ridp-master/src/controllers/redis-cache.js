/**
 * 
 * @author Mallik K
 */
const redis = require('redis');
const asyncRedis = require('async-redis');
const logger = require('../config/logger');

const config = require('../config/config').config;

const client = redis.createClient(process.env.REDIS_PORT || config.redis_port, process.env.REDIS_HOST || config.redis_host);

const asyncRedisClient = asyncRedis.decorate(client);

client.on('connect', () => {
  logger.info('Redis client connected');
});

client.on('error', (err) => {
  logger.error(`Unable to connect to redis cache server ${err}`);
});


/**
 * https://redis.io/commands/set
 * EX seconds -- Set the specified expire time, in seconds.
   PX milliseconds -- Set the specified expire time, in milliseconds.
   https://redis.js.org/
   this key will expire after 10 seconds
   client.set('key', 'value!', 'EX', 10);
 */
exports.setValue = async (key, value, expirySeconds) => {
  let strValue;
  if (typeof value !== 'string') {
    strValue = JSON.stringify(value);
  } else {
    strValue = value;
  }
  
  if (expirySeconds) {
    await asyncRedisClient.set(key, strValue, 'EX', expirySeconds);
  } else {
    await asyncRedisClient.set(key, strValue, 'EX', 300);
  }
};

exports.getValue = async (key) => {
  const cachedValue = await client.get(key);
  return cachedValue;
};