/**
 * This module encapsulates communication with Okta.
 * 
 * @author Kamal V
 */
/* eslint-disable max-len */
const _ = require('lodash');
const cryptoJS = require('crypto-js');
const okta = require('@okta/okta-sdk-nodejs');
const config = require('../config/config').config;
const logger = require('../config/logger');

function getOktaClient() {
  try {
    return new okta.Client({
      orgUrl: process.env.OKTA_ORG_URL || config.okta_org_url,
      token: process.env.OKTA_TOKEN || config.okta_token
    });
  } catch (e) {
    logger.critical('RIDP_OKTA_ERR: Error connecting to Okta', e);
    throw e;
  }
}

const client = getOktaClient();

/**
 * 
 */
module.exports.getUser = async (userId) => {
  let user;
  try {
    user = await client.getUser(userId);
  } catch (e) {
    logger.error(`Error occurred while getting user information from Okta for user ${userId}`, e);
  }
  return user;
};

/**
 * Queries Okta to see if there is any other user object with the same 
 * last name, first name and email address conbination. If there is this 
 * method will return false. Other wise this method will return true.
 */
module.exports.isComboUniqueInOkta = async (userId, lastName, firstName, email) => {
  let isUnique = true;
  try {
    const users = client.listUsers({
      search: `profile.firstName eq "${firstName}" and profile.lastName eq "${lastName}" and profile.email eq "${email}"`
    });

    await users.each((user) => {
      logger.debug(`Okta returned user while performing combo uniqueness check is ${user.profile.login}`);
      if (userId.toLowerCase() !== user.profile.login.toLowerCase()) {
        isUnique = false;
      }
    });
  } catch (e) {
    isUnique = false;
    logger.error(`Error occurred while searching for users in Okta for combo uniqueness check for user ${userId}`, e);
  }
  return isUnique;
};

/**
 * Queries Okta to see if there is any other user object with the 
 * same sha256 hashed SSN. If there is this method will return false.
 * Other wise this method will return true.
 */
module.exports.isSSNUniqueInOkta = async (userId, ssn) => {
  let isUnique = true;
  try {
    const hashedSSN = cryptoJS.SHA256(ssn.replace('-', '')).toString();
    const users = client.listUsers({
      search: `profile.hashedSSN eq "${hashedSSN}"`
    });

    await users.each((user) => {
      logger.debug(`Okta returned user performing ssn uniqueness check is : ${user.profile.login}`);
      if (userId.toLowerCase() !== user.profile.login.toLowerCase()) {
        isUnique = false;
      }
    });
  } catch (e) {
    isUnique = false;
    logger.error(`Error occurred while searching for users in Okta for ssn uniqueness check for user ${userId}`, e);
  }
  logger.debug(`SSN uniqueness check status for user ${userId} is ${isUnique}`);
  return isUnique;
};

/**
 * 
 */
module.exports.updateLOA = async (userId, oktaId, loa) => {
  let response;
  try {
    const user = await client.getUser(userId);
    if (loa === 'LOA2') user.profile.LOA = 2;
    else if (loa === 'LOA3') { user.profile.LOA = 3; }
    response = await user.update();
  } catch (e) {
    logger.error(`Error occurred while getting/updating user : ${userId}`, e);
  }
  return response;
};

/**
 * 
 */
module.exports.updateOktaWithRIDPInfo = async (userId, data) => {
  let response;
  try {
    const user = await client.getUser(userId);
    if (!_.isEmpty(data.referenceNumber)) { user.profile.refNumberRidp = data.referenceNumber; }
    if (!_.isEmpty(data.score)) { user.profile.scoreRidp = data.score; }
    if (!_.isEmpty(data.decision)) { user.profile.decisionCodeRidp = data.decision; }
    if (!_.isEmpty(data.errorCode)) { user.profile.errorCodeRidp = data.errorCode; }
    response = await user.update();
  } catch (e) {
    logger.error(`Error occurred while getting/updating user : ${userId}`, e);
    throw e;
  }
  return response;
};

/**
 * Updates Okta with the updated LOA level as well as 
 * last name, first name, email address, phone number,
 * address line1, cuty, state, zip, dob and hashed SSN.
 * 
 */
module.exports.successUpdate = async (userId, data) => {
  let response;
  try {
    const user = await client.getUser(userId);
    updateUserData(user, data);
    response = await user.update();
    // console.log('RESPONSE FROM OKTA IS : ' + JSON.stringify(response));
  } catch (e) {
    logger.error(`Error occurred while getting/updating user : ${userId}`, e);
  }
  return response;
};

/**
 * Sets the updated values in Okta's user object.
 * 
 * @param {Object} user - Okta returned user object 
 * @param {Object} data - Object that contains user information that was 
 * used to do RIDP
 */
function updateUserData(user, data) {
  const loa = data.requestType;
  if (loa === 'LOA2') user.profile.LOA = 2;
  else if (loa === 'LOA3') { user.profile.LOA = 3; }
  user.profile.firstName = data.firstName;
  user.profile.lastName = data.lastName;
  user.profile.honorificSuffix = data.suffix;
  user.profile.zipExtension = data.address.zipcodeExtn;
  user.profile.streetAddress2 = data.address.line2;
  user.profile.email = data.email;
  user.profile.primaryPhone = data.address.phone.replace(/-/g, '');
  user.profile.streetAddress = data.address.line1;
  user.profile.city = data.address.city;
  user.profile.state = data.address.state;
  user.profile.zipCode = data.address.zipCode;
  user.profile.decisionCodeRidp = 'ACC';
  if (!_.isEmpty(data.ssn)) {
    user.profile.hashedSSN = cryptoJS.SHA256(data.ssn.replace('-', '')).toString();
  }
  user.profile.dateOfBirth = formatDOB(data.dateOfBirth);
}

function formatDOB(dob) {
  const dobTokens = dob.split('-'); // Because of prior validation, we can be sure DOB is always going to be there.
  return `${dobTokens[1]}/${dobTokens[2]}/${dobTokens[0]}`;
}