/**
 * This module deals with communicating with Experian and interpeting 
 * the response sent back from Experian with regards to the answers to 
 * OOW questions.
 * 
 * @author Kamal V
 */
/* eslint-disable max-len */
const _ = require('lodash');
const request = require('request');
const logger = require('../config/logger');
const config = require('../config/config').config;
const ridpUtils = require('../utils/ridp-utils');
const errorMessages = require('../config/config').errorsMessages;
const ridpErrorHandler = require('../utils/error-handler');
const okta = require('../controllers/okta');
const respHandler = require('../utils/response-handler');
const saviynt = require('../controllers/saviynt');

exports.verifyRidpAnswers = (req, res) => {
  const inputData = res.locals.inputData;

  logger.debug(`KIQ answers request for user ${req.user} is ${JSON.stringify(inputData)}`);

  const json = ridpUtils.createKBAAnswersRequest(req.body, inputData);
  const hmacSignature = ridpUtils.calculateHMACSignature(JSON.stringify(json));

  const options = {
    url: process.env.CROSSCORE_URL || config.crosscore_url,
    headers: {
      'hmac-signature': hmacSignature,
      Accept: 'application/json',
      'Content-Type': 'application/json'
    },
    method: 'POST',
    json: true,
    body: json
  };
  if (logger.isLevelEnabled('private')) { logger.private(`Experian Request data is ${JSON.stringify(json)}`); }

  /** Send the request to Experian now. */
  request.post(options, (err, response, body) => {
    try {
      if (err || isSystemError(req.user, body)) {
        logger.critical('RIDP_EXPERIAN_ERR : Network error occurred while contacting Experian CrossCore', err);
        respHandler.handleErrorResponse(res, 500, errorMessages.unexpectedError, err);
      } else {
        // Check to see if the final decision is ACC
        const result = processExperianResponse(req.user, body);
        if (result.decision && result.decision === 'ACC') {
          // Need to add a call back to update Saviynt with the LOA status.
          saviynt.updateProfile(req.user, inputData.requestData).then((updateResponse) => {
            if (_.isEmpty(updateResponse) || updateResponse.errorCode !== '0') {
              okta.successUpdate(req.user, inputData.requestData).then(() => {
                logger.debug(`Updated user ${req.user}'s information with RIDP in Okta successfully`);
                respHandler.handleSuccessResponse(res, '{ status: "SUCCESS" }');
              }).catch((e) => {
                // Should generate an alert here.
                logger.error(`Error occurred while updating LOA status to ${inputData.requestData.requestType} for user ${req.user}`, e);
                respHandler.handleErrorResponse(res, 500, '{ status: "FAILED" }', e);
              });
            } else {
              logger.debug(`Updated LOA status to ${inputData.requestData.requestType} for user ${req.user}`);
              respHandler.handleSuccessResponse(res, '{ status: "SUCCESS" }');
            }
          }).catch((e) => {
            // Should generate an alert here.
            logger.error(`Error occurred while updating LOA status to ${inputData.requestData.requestType} for user ${req.user}`, e);
            respHandler.handleErrorResponse(res, 500, '{ status: "FAILED" }', e);
          });
        } else {
          if (!result.errorCode
            || result.errorCode === '') { result.errorCode = result.decision; }
          logger.debug(`ID proofing did not complete sucessfully for user ${req.user}: Error code is ${result.decision}`);
          // Need to add a call back to update Saviynt with the final decision
          saviynt.updateProfileWithRIDPInfo(req.user, result).then((updateResponse) => {
            if (_.isEmpty(updateResponse) || updateResponse.errorCode !== '0') {
              logger.debug(`Update user ${req.user}'s information in Saviynt failed. now update in OKTA`);
              okta.updateOktaWithRIDPInfo(req.user, result).then(() => {
                logger.debug(`Updated user ${req.user}'s information with RIDP in Okta successfully`);
              }).catch((e) => {
                logger.error(`Error occurred while updating ${req.user} informaiton in Okta. Experian reference number is Reference number is ${result.referenceNumber}`, e);
              });
            }
            respHandler.handleErrorResponse(res, 400,
              ridpErrorHandler.handleSecondRequestErrors(result.errorCode, inputData.referenceNumber));
          });
        }
      }
    } catch (e) {
      logger.error(`Error occurred while processing KIQ answers for user ${req.user}`, e);
      respHandler.handleErrorResponse(res, 500, errorMessages.generalError, e);
    }
  });
};


/**
 * Check to see if we have an error in responseHeader.responseType 
 * node. These errors usually if the headers are not correct or if 
 * the HMAC signature did not match. General observation is
 * these errors are coming from data conversion layer of Experian. 
 * Request did not even made its way to Precise ID.
 *   
 * @param {string} userId
 * @param {*} jsonResponse 
 */
function isSystemError(userId, jsonResponse) {
  let result = false;
  if (_.isEmpty(jsonResponse)) {
    logger.error(`RIDP_EXPERIAN_ERR: Json response from KIQ answers for user ${userId} is empty. Cannot recover from this error.`);
    result = true;
  } else if (jsonResponse.responseHeader.responseType === 'ERROR') {
    logger.error(`RIDP_EXPERIAN_ERR: Unrecoverable error occurred while processing request for user ${userId}. Error message is ${jsonResponse.responseHeader.responseMessage}`);
    result = true;
  }
  return result;
}
/**
 * If the requests made it's way to precise Id, then otherData 
 * (clientResponsePayload.decisionElements[0].otherData) node 
 * should always be there. Any errors precise Id sends are going 
 * to be part of the otherData node. 
 *  
 * @param {*} body 
 * @returns 
 */
function processExperianResponse(userId, body) {
  const result = {};
  if (logger.isLevelEnabled('private')) logger.private(`Response from Experian for the KIQ call by user ${userId} is ${JSON.stringify(body)}`);
  if (body.clientResponsePayload
    && body.clientResponsePayload.decisionElements
    && body.clientResponsePayload.decisionElements[0].otherData) {
    const pidNode = getPIDServerNode(body.clientResponsePayload.decisionElements[0].otherData);
    if (pidNode.error) {
      logger.error(`Error occurred while verifying answers with Experian for user ${userId}. 
                  Error code ${pidNode.error.errorCode} and error 
                  description ${pidNode.error.errorDescription}`);
      result.errorCode = pidNode.error.errorCode;
    } else {
      result.decision = pidNode.summary.finalDecision;
    }
  } else {
    logger.error(`Error occurred while processing OOW answers request for user ${userId}. Experian response body is ${JSON.stringify(body)}`);
    result.errorCode = -100;
    result.decision = 'ERROR';
  }
  return result;
}


/**
 * Experian response is nested pretty deep. This helper function 
 * will return the node that is contains PID Option 24 related 
 * response data.
 * @param {*} otherDataNode 
 */
function getPIDServerNode(otherDataNode) {
  return otherDataNode.json.fraudSolutions.response.products.preciseIDServer;
}