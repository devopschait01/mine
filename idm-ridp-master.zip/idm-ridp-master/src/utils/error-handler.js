/**
 * 
 * @author Kamal V
 */
/* eslint-disable max-len */
const errorMessages = require('../config/config').errorsMessages;

/**
 * 
 */
exports.handleFirstRequestErrors = (errorCode, tryCount, reviewRefNum) => {
  if (tryCount === 1) {
    return handleFirstRequestFirstOccurence(errorCode);
  }
  return handleFirstRequestSecondOccurence(errorCode, reviewRefNum);
};

/**
 * 
 * @param {*} errorCode 
 */
function handleFirstRequestFirstOccurence(errorCode) {
  let result = {};
  switch (errorCode) {
    case 'RF1':
    case 'RF2':
    case 'RF3':
    case 'RF4':
    case '010':
    case '018':
    case '106':
      result = errorMessages.ridpFirstError;
      break;
    case '710':
      result = errorMessages.ridpSessionTimeoutFirstError;
      break;
    case '708':
      result = errorMessages.ridpDataValidationFirstError;
      break;
    case '720':
      result = errorMessages.ridpPreciseIDFirstError;
      break;
    case '403':
      result = errorMessages.ridpSSNRequiredFirstError;
      break;
    case '407':
      result = errorMessages.ridpStandardizeAddressFirstError;
      break;
    case '633':
      result = errorMessages.ridpMaxAddressFirstError;
      break;
    case '258':
    case '259':
    case '323':
    case '324':
    case '352':
      result = errorMessages.unexpectedError;
      break;
    default:
      result = errorMessages.unexpectedError;
  }
  return result;
}

/**
 * 
 * @param {*} errorCode 
 */
function handleFirstRequestSecondOccurence(errorCode, reviewReferenceNumber) {
  let result = {};
  switch (errorCode) {
    case 'RF1':
    case 'RF2':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpFrozenCreditCard, reviewReferenceNumber);
      break;
    case 'RF3':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpAllowedAttempts, reviewReferenceNumber);
      break;
    case 'RF4':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpDeceasedUserError, reviewReferenceNumber);
      break;
    case '010':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpConsumerMinor, reviewReferenceNumber);
      break;
    case '018':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpFraudReport,
        reviewReferenceNumber);
      break;
    case '710':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpSessionTimeoutFirstError,
        reviewReferenceNumber);
      break;
    case '106':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpLastNameError,
        reviewReferenceNumber);
      break;
    case '403':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpSSNRequiredSecondError,
        reviewReferenceNumber);
      break;
    case '407':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpStandardizeAddressSecondError,
        reviewReferenceNumber);
      break;
    case '633':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpMaxAddressSecondError,
        reviewReferenceNumber);
      break;
    case '708':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpDataValidationSecondError,
        reviewReferenceNumber);
      break;
    case '720':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpPreciseIDSecondError,
        reviewReferenceNumber);
      break;
    case '258':
    case '259':
    case '323':
    case '324':
    case '352':
      result = errorMessages.unexpectedError;
      break;
    default:
      result = errorMessages.unexpectedError;
  }
  return result;
}

exports.handleSecondRequestErrors = (errorCode, reviewReferenceNumber) => {
  let result;
  switch (errorCode) {
    case '710':
      result = addReviewReferenceNumberToMessage(errorMessages.ridpSessionTimeoutFirstError,
        reviewReferenceNumber);
      break;
    case 'UNKNOWN':
    default:
      result = addReviewReferenceNumberToMessage(errorMessages.ridpThirdError,
        reviewReferenceNumber);
  }
  return result;
};

/**
 * Error handler for FARS operation
 */
exports.handleFARSErrors = (errorCode) => {
  let result = {};
  switch (errorCode) {
    case '201':
      result = errorMessages.farsNotAccError;
      break;
    case '202':
      result = errorMessages.fars9001Error;
      break;
    case '203':
      result = errorMessages.unexpectedError;
      break;
    case '204':
      result = errorMessages.farsUserNotFound;
      break;
    case 'MISMATCH':
      result = errorMessages.farsUserDataMismatch;
      break;
    default:
      result = errorMessages.unexpectedError;
  }
  return result;
};

function addReviewReferenceNumberToMessage(error, reviewReferenceNumber) {
  if (error.errorMessage.includes('reviewRefNum')) {
    return { errorCode: error.errorCode, errorMessage: error.errorMessage.replace('#{reviewRefNum}', reviewReferenceNumber) };
  }
  return error;
}