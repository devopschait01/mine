/**
 * Bootstrap file to start the IDM RIDP Microservice.
 *  
 * @author Kamal V
 */
const express = require('express');
const httpContext = require('express-http-context');

const app = express();
const _ = require('lodash');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const addRequestId = require('express-request-id')();
const cors = require('cors');
const shortid = require('shortid');
const startHRTime = require('./src/middleware/start-time');
const logger = require('./src/config/logger');
const ridp = require('./src/routes/ridp');
const dbUtils = require('./src/utils/db-utils');

app.use(morgan('combined', { stream: logger.stream }));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(addRequestId);
app.use(cors()); // For the timebeing all domains are whitelisted.

app.use(httpContext.middleware);

app.use((req, res, next) => {
  let txId = req.header('x-idm-txid');
  if (_.isEmpty(txId)) {
    txId = shortid.generate();
  }
  res.locals.txId = txId;
  req.txId = txId;
  res.set('x-idm-txid', txId);
  httpContext.set('txId', txId);
  next();
});

// Register the 'after response' middleware so that
// audit logging can be performed.
app.use((req, res, done) => {
  function postProcess() {
    //  remove the event listeners, ensuring postProcess
    //  only gets called once
    res.removeListener('finish', postProcess);
    res.removeListener('close', postProcess);
    process.nextTick(async () => {
      dbUtils.insertAuditEvent(req, res).then(() => {
      }).catch((e) => {
        logger.critical('RIDP_DB_ERR: Error occurred while inseriting audit data', e);
      });
    });
  }
  res.on('finish', postProcess);
  res.on('close', postProcess);


  if (done) { done(); }
});

app.use('/api/v1/idm/ridp', startHRTime.insertstartHRTime, ridp);

app.use((req, res, next) => {
  const error = new Error('Not supported');
  error.status = 404;
  next(error);
});

app.use((error, req, res) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message
    }
  });
});

module.exports = app;