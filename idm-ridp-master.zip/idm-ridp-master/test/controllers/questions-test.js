// /* eslint-disable no-unused-vars */
// /* eslint-disable import/newline-after-import */
// /* eslint-disable linebreak-style */
// /* eslint-disable no-undef */
// const sinon = require('sinon');
// const request = require('request');
// const chai = require('chai');
// const should = chai.should();
// const mockReq = require('sinon-express-mock').mockReq;
// const ridpUtils = require('../../src/utils/ridp-utils');
// const expect = require('chai').expect;
// const sinonChai = require('sinon-chai');
// const questionsController = require('../../src/controllers/questions');
// const logger = require('../../src/config/logger');
// const okta = require('../../src/controllers/okta');
// const saviynt = require('../../src/controllers/saviynt');
// const redis = require('../../src/controllers/redis-cache');

// const inputJSON = require('../test-data/ridp-input-data.json');
// const successJSON = require('../test-data/oow-questions-success-response.json');

// chai.use(sinonChai);

// describe('IDM RIDP Question Controller Unit Tests', () => {
//   let responseObject;
//   const base = 'http://localhost:3000';

//   const req = mockReq();

//   const mockResponse = () => {
//     const res = {};
//     res.locals = {};
//     res.status = sinon.stub().returns(res);
//     res.json = sinon.stub().returns(res);
//     return res;
//   };

//   beforeEach(() => {
//     responseObject = {
//       statusCode: 200,
//       headers: {
//         'content-type': 'application/json'
//       }
//     };
//     this.getValue = sinon.stub(redis, 'getValue');
//     this.setValue = sinon.stub(redis, 'setValue');
//     this.calculateHMACSignature = sinon.stub(ridpUtils, 'calculateHMACSignature');
//     this.generateJWTToken = sinon.stub(ridpUtils, 'generateJWTToken');
//     this.updateProfileWithRIDPInfo = sinon.stub(saviynt, 'updateProfileWithRIDPInfo');
//     this.updateOktaWithRIDPInfo = sinon.stub(okta, 'updateOktaWithRIDPInfo');
//     this.post = sinon.stub(request, 'post');
//   });

//   afterEach(() => {
//     ridpUtils.calculateHMACSignature.restore();
//     ridpUtils.generateJWTToken.restore();
//     saviynt.updateProfileWithRIDPInfo.restore();
//     redis.getValue.restore();
//     redis.setValue.restore();
//     request.post.restore();
//     okta.updateOktaWithRIDPInfo.restore();
//   });
//   describe('GET /api/v1/idm/ridp/questions', () => {
//     it('should questions successfully', (done) => {
//       this.getValue.returns({});
//       this.setValue.returns({});
//       this.calculateHMACSignature.returns({});
//       this.generateJWTToken.returns({});
//       this.updateProfileWithRIDPInfo.returns({ errorCode: '0' });
//       this.updateOktaWithRIDPInfo.resolves(''); // Stubbing okta update.
//       const res = mockResponse();
//       req.body = inputJSON;
//       req.user = 'kamal@rrinfotechinc.com';
//       this.post.yields(null, responseObject, successJSON);
//       questionsController.viewRidpQuestions(req, res);
//       expect(res.status).to.be.calledWith(200);
//       done();
//     });

//     it('should generate system error', (done) => {
//       this.getValue.returns({});
//       this.setValue.returns({});
//       this.calculateHMACSignature.returns({});
//       this.generateJWTToken.returns({});
//       this.updateProfileWithRIDPInfo.returns({ errorCode: '0' });
//       this.updateOktaWithRIDPInfo.resolves(''); // Stubbing okta update.
//       const res = mockResponse();
//       req.body = inputJSON;
//       req.user = 'kamal@rrinfotechinc.com';
//       this.post.yields(null, responseObject, successJSON);
//       questionsController.viewRidpQuestions(req, res);
//       expect(res.status).to.be.calledWith(200);
//       done();
//     });

//     it('should not generate questions', (done) => {
//       this.getValue.returns({});
//       this.setValue.returns({});
//       this.calculateHMACSignature.returns({});
//       this.generateJWTToken.returns({});
//       this.updateProfileWithRIDPInfo.returns({ errorCode: '0' });
//       this.updateOktaWithRIDPInfo.resolves(''); // Stubbing okta update.
//       const res = mockResponse();
//       req.body = inputJSON;
//       req.user = 'kamal@rrinfotechinc.com';
//       this.post.yields(null, responseObject, successJSON);
//       questionsController.viewRidpQuestions(req, res);
//       expect(res.status).to.be.calledWith(200);
//       done();
//     });
//   });
// });