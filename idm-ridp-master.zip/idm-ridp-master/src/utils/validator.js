
/**
 * The purpose of this module is to validate the input data coming into all 3 RIDP rest services.
 * 
 * @author Kamal V
 */

/* eslint-disable max-len */
/* eslint-disable no-useless-escape */
/* eslint-disable no-param-reassign */

const BaseJoi = require('@hapi/joi');
const Extension = require('@hapi/joi-date');
const logger = require('../config/logger');
const config = require('../config/config');
const errorMessages = require('../config/config').errorsMessages;
const jwtUtils = require('./jwt-utils');
const stateAbbreviations = require('./state-abbreviations.json');
const respHandler = require('../utils/response-handler');
const redactUtils = require('./redact-utils');

const Joi = BaseJoi.extend(Extension);
const cutoffDate = new Date(Date.now() - (1000 * 60 * 60 * 24 * 365 * 18));

const schema = Joi.object().keys({
  // userId: Joi.string().allow(''),
  // reviewRef: Joi.string().allow(''),
  requestType: Joi.string().valid(['LOA2', 'LOA3']).required().error((errors) => {
    errors.forEach((err) => {
      switch (err.type) {
        case 'any.empty':
        case 'any.required':
          err.message = errorMessages.requestTypeEmpty;
          break;
        default:
          err.message = errorMessages.requestTypeInvalid;
      }
    });
    return errors[0];
  }),
  firstName: Joi.string().required().regex(/^[a-zA-Z- \']{1,20}$/).required()
    .error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.firstNameEmpty;
            break;
          default:
            err.message = errorMessages.firstNameInvalid;
            break;
        }
      });
      return errors[0];
    }),
  middleName: Joi.string().regex(/^[a-zA-Z- \']{1,20}$/).allow('').error((errors) => {
    errors.forEach((err) => {
      switch (err.type) {
        default:
          err.message = errorMessages.middleNameInvalid;
          break;
      }
    });
    return errors[0];
  }),
  suffix: Joi.string().valid(['SR', 'JR', 'II', 'III', 'IV']).allow('').error((errors) => {
    errors.forEach((err) => {
      switch (err.type) {
        default:
          err.message = errorMessages.suffixInvalid;
          break;
      }
    });
    return errors[0];
  }),
  lastName: Joi.string().regex(/^[a-zA-Z- \']{1,25}$/).required().error((errors) => {
    errors.forEach((err) => {
      switch (err.type) {
        case 'any.empty':
        case 'any.required':
          err.message = errorMessages.lastNameEmpty;
          break;
        default:
          err.message = errorMessages.lastNameInvalid;
          break;
      }
    });
    return errors[0];
  }),
  // ssn: [Joi.string(), Joi.number()],
  ssn: Joi.when('requestType', {
    is: 'LOA3',
    then: Joi.string().regex(/^(?!000|9\d{2})\d{3}-(?!00)\d{2}-(?!0{4})\d{4}$/).required(),
    otherwise: Joi.string().regex(/^(?!000|9\d{2})\d{3}-(?!00)\d{2}-(?!0{4})\d{4}$/).allow('')
  }).error((errors) => {
    errors.forEach((err) => {
      switch (err.type) {
        case 'any.empty':
        case 'any.required':
          err.message = errorMessages.ssnEmpty;
          break;
        default:
          err.message = errorMessages.ssnInvalid;

          break;
      }
    });
    return errors[0];
  }),

  email: Joi.string().regex(/^([a-zA-Z0-9_\'\.-]+)@([a-zA-Z0-9_\.-]+)\.([a-zA-Z]{2,5})$/).regex(/^.{4,74}$/).required()
    .error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.emailEmpty;
            break;
          default:
            err.message = errorMessages.emailInvalid;
            break;
        }
      });
      return errors[0];
    }),


  dateOfBirth: Joi.date().format('YYYY-MM-DD').max(cutoffDate).required()
    .error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.required':
          case 'any.empty':
            err.message = errorMessages.dateOfBirthEmpty;
            break;
          case 'date.max':
            err.message = errorMessages.ageInvalid;
            break;
          default:
            err.message = errorMessages.dateOfBirthInvalid;
            break;
        }
      });
      return errors[0];
    }),
  address: {
    type: Joi.string().valid(['US']).required().error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.addressTypeEmpty;
            break;
          default:
            err.message = errorMessages.addressTypeInvalid;
            break;
        }
      });
      return errors[0];
    }),
    line1: Joi.string().regex(/^[a-zA-Z0-9 \.-]{3,64}$/).required().error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.addressLine1Empty;
            break;
          default:
            err.message = errorMessages.addressLine1Invalid;
            break;
        }
      });
      return errors[0];
    }),
    line2: Joi.string().regex(/^[a-zA-Z0-9 \.-]{3,64}$/).allow('').error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          default:
            err.message = errorMessages.addressLine2Invalid;
            break;
        }
      });
      return errors[0];
    }),
    city: Joi.string().regex(/^[a-zA-Z\'-\s]{2,20}$/).required().error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.cityEmpty;
            break;
          default:
            err.message = errorMessages.cityInvalid;
            break;
        }
      });
      return errors[0];
    }),
    state: Joi.string().valid(stateAbbreviations.states).required().error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.stateEmpty;
            break;
          default:
            err.message = errorMessages.stateInvalid;
            break;
        }
      });
      return errors[0];
    }),
    zipCode: Joi.string().regex(/^\d{5}$/).required().error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.empty':
          case 'any.required':
            err.message = errorMessages.zipcodeEmpty;
            break;
          default:
            err.message = errorMessages.zipcodeInvalid;
            break;
        }
      });
      return errors[0];
    }),
    zipcodeExtn: Joi.string().regex(/^\d{4}$/).min(0).allow('')
      .error((errors) => {
        errors.forEach((err) => {
          switch (err.type) {
            default:
              err.message = errorMessages.zipcodeExtnInvalid;
              break;
          }
        });
        return errors[0];
      }),
    phone: Joi.string().regex(/^[2-9][0-9]{2}\-?[0-9]{3}\-?[0-9]{4}$/).required().error((errors) => {
      errors.forEach((err) => {
        switch (err.type) {
          case 'any.required':
          case 'any.empty':
            err.message = errorMessages.phoneEmpty;
            break;
          default:
            err.message = errorMessages.phoneInvalid;
            break;
        }
      });
      return errors[0];
    })
  }

});


/**
 * If route is questions, then request type is required. If 
 * the route is phone_proofing_status, request type is not required.
 */
exports.validateRidpInputData = (req, res, next) => {
  const data = req.body;

  Joi.validate(data, schema, { abortEarly: false }).then(() => {
    next();
  }).catch((e) => {
    const respObj = [];
    e.details.forEach((item) => {
      respObj.push(item.message);
    });
    if (logger.isLevelEnabled('debug')) { logger.debug(`Data validation failure occurred: ${JSON.stringify(respObj)}`); }
    respHandler.handleErrorResponse(res, 400, respObj);
  });
};


/**
 * This method checks to make sure that the inputDataToken is a 
 * valid JWT token. For performance reasons once the token is 
 * validated, the payload is extracted and injected into the 
 * response so that we don't go through the process of extracting 
 * the payload again.
 * 
 * Note: This is definately not the best thing to do. But untill 
 * another was is found out, will go with this.
 *
 * @param {*} inputDataToken
 * @param {*} resp
 */
function validInputData(inputDataToken, res) {
  if (inputDataToken && inputDataToken.length > 0) {
    const jwtResponseObj = jwtUtils.verify(inputDataToken, config.jwt_token_expiresIn);

    // Kind of weired. No type safety here.
    if (typeof jwtResponseObj === 'boolean') {
      return false;
    }
    // eslint-disable-next-line no-param-reassign
    res.locals.inputData = jwtResponseObj.inputData;
    // This is kind of bad. For performance reasons this is done like this.
    // Look for a better way to do this. Method name is validate, so it should
    // just do the validation and nothing else.
  } else {
    return false;
  }
  return true;
}

/**
 * Checks to make sure request body contains the answers as well as 
 * input data with the session id. Also a check is done to make sure 
 * the number of answers matches question count that is part of inputData.
 *
 * @param {*} body
 * @param {*} inputData
 */
function validateAnswers(body, inputData) {
  let isValid = true;
  if (logger.isLevelEnabled('debug')) { logger.debug(`Validating OOQ Answers : Body is ${JSON.stringify(body)} and INPUT Data is ${redactUtils.redact(inputData.requestData, true)}`); }
  if (inputData && inputData.sessionId && body.answers
    && body.answers.length === inputData.questionsCount) {
    body.answers.forEach((item) => {
      if (!item.answer || item.answer.length < 1) {
        isValid = false;
      }
    });
  } else {
    if (logger.isLevelEnabled('debug')) { logger.debug(`OOW answers input data is not valid : ${JSON.stringify(body)}`); }
    isValid = false;
  }
  return isValid;
}

/**
 * Validates the input data to check the following:
 * 1) inputDataToken is present and is valid.
 * 2) Number of answers matches with the number of questions in the inputData
 * 3) There is atleast 1 char for each answer
 * 4) Session id is present
 *
 * If anyone of the above fails, a validation error will be sent back.
}
 */
exports.vaidateAnswers = (req, res, next) => {
  if (!validInputData(req.body.inputDataToken, res)) {
    // const respObj = [];
    // logger.info('TOKEN Validation failed');
    // respObj.push(errorMessages.jwtTokenValidationFailure);
    respHandler.handleErrorResponse(res, 400, errorMessages.jwtTokenValidationFailure);
    // resp.status(400).json({ errors: respObj });
    return;
  } if (!validateAnswers(req.body, res.locals.inputData)) {
    // const respObj = [];
    // respObj.push(errorMessages.kiqAnswersValidationFailure);
    respHandler.handleErrorResponse(res, 400, errorMessages.kiqAnswersValidationFailure);
    // res.status(400).json({ errors: respObj });
    return;
  }
  next();
};