// /* eslint-disable no-unused-vars */
// /* eslint-disable import/newline-after-import */
// /* eslint-disable linebreak-style */
// /* eslint-disable no-undef */
// const sinon = require('sinon');
// const request = require('request');
// const chai = require('chai');
// const should = chai.should();
// const mockReq = require('sinon-express-mock').mockReq;
// const questionsController = require('../../src/controllers/questions');
// const logger = require('../../src/config/logger');
// const okta = require('../../src/controllers/okta');
// const expect = require('chai').expect;
// const sinonChai = require('sinon-chai');
// const authCheck = require('../../src/middleware/auth-check');

// const inputJSON = require('../test-data/ridp-input-data.json');
// const successJSON = require('../test-data/oow-questions-success-response.json');

// chai.use(sinonChai);

// describe('IDM RIDP: Router Unit Tests', () => {
//   let responseObject;
//   const base = 'http://localhost:3000';

//   let req = mockReq();

//   const mockResponse = () => {
//     const res = {};
//     res.locals = {};
//     res.status = sinon.stub().returns(res);
//     res.json = sinon.stub().returns(res);
//     return res;
//   };

//   beforeEach(() => {
//     responseObject = {
//       statusCode: 200,
//       headers: {
//         'content-type': 'application/json'
//       }
//     };
//     this.authorize = sinon.stub(authCheck, 'authorize');
//     this.updateOktaWithRIDPInfo = sinon.stub(okta, 'updateOktaWithRIDPInfo');
//     this.post = sinon.stub(request, 'post');
//   });

//   afterEach(() => {
//     request.post.restore();
//     okta.updateOktaWithRIDPInfo.restore();
//     authCheck.authorize.restore();
//   });
//   describe('GET /api/v1/idm/ridp/questions', () => {

//     it('should questions successfully', (done) => {
//       this.updateOktaWithRIDPInfo.resolves(''); // Stubbing okta update.
//       req.user = 'kamal@rrinfotechinc.com';
//       req.client = 'test';
//       this.authorize.yields();
//       const res = mockResponse();
//       req.body = inputJSON;
//       req.user = 'kamal@rrinfotechinc.com';
//       this.post.yields(null, responseObject, successJSON);
      
//       expect(res.status).to.be.calledWith(200);
//       // expect(res.json).to.be.calledWith('{}'); // since inputtoken is generated dynamically, it is almost impossible to have this.
//     });
//   });
// });