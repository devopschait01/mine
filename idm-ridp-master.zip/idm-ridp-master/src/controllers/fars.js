/**
 * 
 * @author Kamal V
 */
/* eslint-disable no-lonely-if */
/* eslint-disable max-len */
const request = require('request');
const _ = require('lodash');
const logger = require('../config/logger');
const farsUtils = require('../utils/fars-utils');
const errorHandler = require('../utils/error-handler');
const okta = require('../controllers/okta');
const errorMessages = require('../config/config').errorsMessages;
const redactUtils = require('../utils/redact-utils');
const saviynt = require('../controllers/saviynt');

/**
 * Checks to see if we have a status of ACC in FinalDecision field. 
 */
exports.verifyPhoneProofing = (req, res) => {
  if (logger.isLevelEnabled('private')) { logger.debug(`FARS request body for user ${req.user} is ${redactUtils.redact(req.body, true)}`); }

  // Get user from Okta first and get the review referene number.
  okta.getUser(req.user).then((user) => {
    const reviewRefNum = user.profile.refNumberRidp;
    if (isUserAlreadyAtRequiredLOALevel(user)) {
      handleErrorResponse(res, 400, errorMessages.ridpNotRequired);
    } else if (_.isEmpty(reviewRefNum)) {
      logger.debug(`Invalid review reference number ${reviewRefNum}. So FARS request cannot continue for ${req.user}`);
      // Existing logic looks for the decision code to be not ACC. Not sure if
      // that is still needed.
      handleErrorResponse(res, 400, errorMessages.invalidReviewReferenceNumber);
    } else {
      logger.debug(`Starting FARS call for user ${req.user} and review reference number ${reviewRefNum}`);
      request(farsUtils.getFARSConnectionDetails(reviewRefNum), (error, response, body) => {
        if (!error) {
          if (response.statusCode === 204) {
            handleErrorResponse(res, 400, errorHandler.handleFARSErrors('204'));
          } else {
            if (logger.isLevelEnabled('private')) {
              logger.private(`FARS Response from experian for review reference id ${req.body.reviewRef} is ${JSON.stringify(body)}`);
            }
            const farsResponse = farsUtils.getFARSDetailsFromResponse(response.statusCode, body);

            if (farsResponse.finalStatus !== 200) {
              handleErrorResponse(res, 400, errorHandler.handleFARSErrors(farsResponse.finalStatus));
            } else {
              if (farsUtils.isAllDataPresentInFARSResponse(farsResponse.userInfo, req.body.requestType)
                && farsUtils.isUserInputDataMatchWithFARS(req.body, farsResponse.userInfo)) {
                saviynt.updateProfile(req.user, req.body).then((updateResponse) => {
                  if (_.isEmpty(updateResponse) || updateResponse.errorCode !== '0') {
                    logger.debug(`Update user ${req.user}'s information in Saviynt failed. now update in OKTA`);
                    okta.successUpdate(req.user, req.body).then(() => {
                      logger.debug(`Updated LOA status to ${req.body.requestType} for user ${req.user}`);
                      handleSuccessResponse(res, { status: 'SUCCESS' });
                    }).catch((e) => {
                      logger.error(`Error occurred while updating LOA status to ${req.body.requestType} for user ${req.user} in OKTA`, e);
                      handleErrorResponse(res, 400, { status: 'FAILED' });
                    });
                  } else {
                    handleSuccessResponse(res, { status: 'SUCCESS' });
                  }
                });
              } else {
                handleErrorResponse(res, 400, errorHandler.handleFARSErrors('MISMATCH'));
              }
            }
          }
        } else {
          logger.error('IDM_RIDP_ERROR_001 : System error occurred while contacting Experian FARS', error);
          handleErrorResponse(res, 500, errorMessages.unexpectedError);
        }
      });
    }
  }).catch((e) => {
    logger.error(`Error occurred while getting user ${req.user} information from Okta `, e);
    handleErrorResponse(res, 500, errorMessages.unexpectedError, e);
  });
};

function handleErrorResponse(res, code, errorObj, err) {
  const msg = { errors: [errorObj] };
  if (err) { res.locals.response = { errors: err.toString() }; } else { res.locals.response = msg; }
  res.status(code).json(msg);
}

function handleSuccessResponse(res, msgObj) {
  res.locals.response = msgObj;
  res.status(200).json(msgObj);
}

function isUserAlreadyAtRequiredLOALevel(user) {
  const reviewRefNum = user.profile.refNumberRidp;
  const loa = user.profile.LOA;
  if (loa === '3') {
    logger.info(`User ${user.profile.login} is already at the max LOA level. 
                So there is no need of FARS call.`);
    return true;
  }
  if (!_.isEmpty(reviewRefNum) && reviewRefNum.startsWith('L2') && loa === '2') {
    logger.info(`User ${user.profile.login} is already at the max LOA level. So there is no need of FARS call.`);
    return true;
  }
  return false;
}