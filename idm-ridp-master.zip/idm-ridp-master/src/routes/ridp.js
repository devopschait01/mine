/**
 * Routes for all RIDP services.
 *
 * @author Kamal V
 */

const express = require('express');

const router = express.Router();
const validator = require('../utils/validator');
const oktaValidator = require('../utils/okta-validator');
const ridpController = require('../controllers/questions');
const ridpAnswersController = require('../controllers/answers');
const farsController = require('../controllers/fars');
const authCheck = require('../middleware/auth-check');

/**
 * This route is to get the questions from Experian crosscore. 
 * Data is validated first before call is made to Experian CrossCore.
 */
router.post('/questions',
  authCheck.authorize,
  oktaValidator.isRIDPRequired,
  validator.validateRidpInputData,
  oktaValidator.isDataUnique,
  ridpController.viewRidpQuestions);

/**
 * This route is to validate the answers provided by the user.
 * Data validation is performed first before sending the call
 * for validation to Experian CrossCore.  
 */
router.post('/answers',
  authCheck.authorize,
  validator.vaidateAnswers,
  ridpAnswersController.verifyRidpAnswers);

/**
* This route will validate the input data that is submitted as 
* part of the phone proofing status check and if the validation is successful,
* makes a call to Experian to check the phone proofing status check. 
*/
router.post('/phone_proofing_status',
  authCheck.authorize,
  validator.validateRidpInputData,
  oktaValidator.isDataUnique,
  farsController.verifyPhoneProofing);


module.exports = router;