/**
 * 
 * @author Kamal V
 */

/* eslint-disable prefer-template */
/* eslint-disable new-cap */
/* eslint-disable no-restricted-syntax */
/* eslint-disable max-len */

const appRoot = require('app-root-path');
const winston = require('winston');
const { format } = require('winston');
const httpContext = require('express-http-context');

const { combine, timestamp, printf } = format;

const myFormat = printf((info) => {
  const txId = httpContext.get('txId') || '';
  const user = httpContext.get('user') || '';
  return (`[${info.timestamp}] [${info.level}] [${user}] [${txId}] : ${info.message}` + (info.splat !== undefined ? `${info.splat}` : ' '));
});

const options = {
  file: {
    level: process.env.LOGLEVEL || 'debug',
    prettyPrint: true,
    handleExceptions: true,
    json: false,
    colorize: true,
    name: 'file',
    filename: `${appRoot}/logs/idmridp.log`,
    maxsize: 10485760, // 10MB
    maxFiles: 5
  },
  console: {
    name: 'console',
    prettyPrint: true,
    level: process.env.LOGLEVEL || 'info',
    handleExceptions: true,
    colorize: true,
    json: false
  }
};

const RFC5424Levels = {
  levels: {
    emerg: 0,
    alert: 1,
    critical: 2,
    error: 3,
    warning: 4,
    notice: 5,
    info: 6,
    debug: 7,
    private: 8
  }
};

const logger = new winston.createLogger({
  levels: RFC5424Levels.levels,
  format: combine(
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.splat(),
    myFormat
  ),
  transports: [
    new winston.transports.File(options.file),
    new winston.transports.Console(options.console)
  ],
  exitOnError: false
});

logger.stream = {
  write(message) {
    logger.info(message);
  }
};

logger.isLevelEnabled = (level) => {
  let enabled = false;
  logger.transports.forEach((transport) => {
    if (logger.levels[transport.level] >= logger.levels[level]) { enabled = true; } else { enabled = false; }
  });
  return enabled;
};


module.exports = logger;