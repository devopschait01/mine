/**
 * TODO: The entire configuration strategy should be revisited. 
 * Probably should leverage AWS Secrets Manager or something
 * along those lines. 
 * 
 * THIS IS A TEMP SETUP AT THIS POINT.
 */
const config = require('../../config.json');
const errorsMessages = require('./error-details.json');

module.exports = {
  config,
  errorsMessages
};